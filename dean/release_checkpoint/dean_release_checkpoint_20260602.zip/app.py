from __future__ import annotations

import json
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

import streamlit as st

from core.action_engine import ActionResult, execute_command, execute_plan
from core.action_safety import (
    affected_columns,
    affected_row_count,
    change_summary,
    is_delete_row_action,
)
from core.audit_logger import log_audit_event
from core.command_schema import OPERATORS_WITHOUT_VALUE, SUPPORTED_ACTIONS, VALID_OPERATORS, default_command
from core.correction_manager import save_correction, sync_learning_files
from core.excel_loader import load_excel_workbook
from core.exporter import export_edited_workbook, export_workbook_copy
from core.logger import log_user_request
from core.privacy_controls import load_privacy_settings
from core.validator import validate_command
from core.workbook_diagnostics import (
    diagnose_workbook,
    diagnostics_for_sheet,
    sheet_requires_edit_warning,
)
from core.institution_context import InstitutionMode, Role
from core.workbook_profiler import profile_workbook
from database.db import initialize_database
from nlp.llm_json_parser import command_to_confirmation
from nlp.synonym_mapper import load_json, match_column_by_terms, match_column_for_concept, normalize_text
from core.attendance import load_attendance_file, match_attendance_to_roster
from core.data_sources import AttendanceSource, DataSourceRegistry
from core.excel_loader import LoadedWorkbook
from ui.chat_panel import (
    ensure_session_workbook,
    render_chat_panel,
    render_live_output_panel,
    route_message,
)
from ui.correction_screen import render_feedback_screen, render_learning_admin
from ui.auth_screen import render_user_admin, render_user_bar, require_login
from ui.figures_panel import (
    ChartIntent,
    build_altair_chart,
    export_latest_figure_csv,
    render_figures_panel,
)
from ui.privacy_admin import render_privacy_admin
from ui.health_check import render_workbook_health_check
from ui.results_panel import render_answer_view, render_clarify_view, render_edit_plan_summary
from ui.settings_panel import render_settings_panel
from core.risk_settings import load_risk_settings


st.set_page_config(
    page_title="Offline University Spreadsheet Assistant",
    page_icon="",
    layout="wide",
)


def render_sheet_metadata(sheet_profile) -> None:
    with st.expander(sheet_profile.name, expanded=True):
        st.metric("Rows", sheet_profile.row_count)

        if sheet_profile.columns:
            st.write("Columns")
            st.code("\n".join(sheet_profile.columns), language="text")
        else:
            st.info("No columns found on this sheet.")


def render_action_builder(profile) -> dict[str, Any]:
    st.write("Action Builder")

    action = st.selectbox("Action", sorted(SUPPORTED_ACTIONS))
    sheet = st.selectbox("Sheet", profile.sheet_names)
    sheet_profile = next(item for item in profile.sheets if item.name == sheet)
    columns = sheet_profile.columns

    command: dict[str, Any] = {
        "action": action,
        "sheet": sheet,
    }

    if action == "create_chart":
        chart_type = st.selectbox(
            "Chart type",
            ["bar", "column", "line", "pie", "stacked_bar"],
        )
        metric = st.selectbox(
            "Metric",
            ["count_rows", "sum", "count_missing"],
        )
        command["chart_type"] = chart_type
        command["metric"] = metric
        command["group_by"] = st.selectbox("Group by", columns or [""])

        if metric in {"sum", "count_missing"}:
            command["value_column"] = st.selectbox("Value column", columns or [""])

        default_sheet_name = f"{command['group_by']} Chart" if command.get("group_by") else "Chart"
        command["output_sheet"] = st.text_input("Output sheet", value=default_sheet_name)
        command["title"] = st.text_input("Chart title", value=default_sheet_name)

    elif action == "create_report":
        report_type = st.selectbox(
            "Report type",
            [
                "enrollment_summary",
                "missing_fafsa",
                "outstanding_balance",
                "inactive_withdrawn",
                "program_enrollment",
                "advisor_caseload",
                "registration_status",
                "missing_fafsa_and_balance",
            ],
        )
        command["report_type"] = report_type
        command["include_summary"] = st.checkbox("Include summary", value=True)
        command["include_chart"] = st.checkbox("Include chart", value=True)
        command["output_sheet"] = st.text_input("Output sheet", value=report_type.replace("_", " ").title())
        st.caption("Use Natural language or Manual JSON to add report-specific filters.")

    elif action == "create_data_quality_report":
        command["output_sheet"] = st.text_input("Output sheet", value="Data Quality Report")
        st.caption("Scans common enrollment data issues and writes issue summaries with example row numbers only.")

    elif action == "create_formula":
        formula_type = st.selectbox(
            "Formula type",
            ["IF", "SUM", "AVERAGE", "COUNT", "COUNTA", "COUNTIF", "SUMIF", "XLOOKUP", "CONCAT", "TEXT", "TODAY"],
        )
        command["formula_type"] = formula_type

        if formula_type == "IF":
            new_column = st.text_input("New column", value="Formula Flag")
            condition_col, operator_col, value_col = st.columns([2, 2, 2])
            with condition_col:
                condition_column = st.selectbox("Condition column", columns)
            with operator_col:
                operator = st.selectbox("Formula operator", sorted(VALID_OPERATORS))
            with value_col:
                value = st.text_input("Formula value", value="0")
            command["new_column"] = new_column
            command["logic"] = {
                "condition_column": condition_column,
                "operator": operator,
                "true_value": "Yes",
                "false_value": "No",
            }
            if operator not in {"is_missing", "is_not_missing"}:
                command["logic"]["value"] = _parse_json_value(value)

        elif formula_type in {"SUM", "AVERAGE", "COUNT", "COUNTA", "TEXT"}:
            command["column"] = st.selectbox("Formula column", columns or [""])
            if formula_type == "TEXT":
                command["new_column"] = st.text_input("New column", value=f"{command['column']} Text")
                command["format_text"] = st.text_input("Excel TEXT format", value="0")

        elif formula_type in {"COUNTIF", "SUMIF"}:
            condition_col, operator_col, value_col = st.columns([2, 2, 2])
            with condition_col:
                criteria_column = st.selectbox("Criteria column", columns)
            with operator_col:
                operator = st.selectbox("Criteria operator", sorted(VALID_OPERATORS))
            with value_col:
                value = st.text_input("Criteria value", value="0")
            criterion = {"column": criteria_column, "operator": operator}
            if operator not in {"is_missing", "is_not_missing"}:
                criterion["value"] = _parse_json_value(value)
            command["criteria"] = [criterion]
            if formula_type == "SUMIF":
                command["sum_column"] = st.selectbox("Sum column", columns or [""])

        elif formula_type == "XLOOKUP":
            command["new_column"] = st.text_input("New column", value="Lookup Result")
            lookup_sheets = [name for name in profile.sheet_names if name != sheet]
            if lookup_sheets:
                lookup_sheet = st.selectbox("Lookup sheet", lookup_sheets)
                lookup_columns = _selected_sheet_columns(profile, lookup_sheet)
                command["lookup"] = {
                    "lookup_sheet": lookup_sheet,
                    "lookup_value_column": st.selectbox("Value column on this sheet", columns),
                    "lookup_key_column": st.selectbox("Key column on lookup sheet", lookup_columns),
                    "return_column": st.selectbox("Return column", lookup_columns),
                }
            else:
                st.warning("Add another sheet to build a lookup formula.")

        elif formula_type == "CONCAT":
            command["new_column"] = st.text_input("New column", value="Combined Text")
            command["columns"] = st.multiselect("Columns to concatenate", columns, default=columns[:2])

    elif action in {"filter_rows", "highlight_rows"}:
        if not columns:
            st.warning("This sheet has no columns available for conditions.")
            return command

        condition_col, operator_col, value_col = st.columns([2, 2, 2])
        with condition_col:
            column = st.selectbox("Condition column", columns)
        with operator_col:
            operator = st.selectbox("Operator", sorted(VALID_OPERATORS))
        with value_col:
            value = st.text_input("Value", value="0")

        condition: dict[str, Any] = {
            "column": column,
            "operator": operator,
        }
        if operator not in {"is_missing", "is_not_missing"}:
            condition["value"] = _parse_json_value(value)
        command["conditions"] = [condition]

        if action == "highlight_rows":
            fill_color = st.selectbox(
                "Fill color",
                ["yellow", "green", "red", "blue", "orange"],
            )
            command["format"] = {"fill_color": fill_color}

    elif action == "sum_column":
        numeric_candidates = columns or [""]
        command["column"] = st.selectbox("Column to sum", numeric_candidates)

    elif action == "count_rows":
        use_condition = st.checkbox("Count only rows matching a condition")
        if use_condition and columns:
            condition_col, operator_col, value_col = st.columns([2, 2, 2])
            with condition_col:
                column = st.selectbox("Count condition column", columns)
            with operator_col:
                operator = st.selectbox("Count operator", sorted(VALID_OPERATORS))
            with value_col:
                value = st.text_input("Count value", value="0")
            condition = {
                "column": column,
                "operator": operator,
            }
            if operator not in {"is_missing", "is_not_missing"}:
                condition["value"] = _parse_json_value(value)
            command["conditions"] = [condition]

    elif action == "count_by_group":
        command["group_by"] = st.selectbox("Group by column", columns or [""])

    elif action == "detect_missing_values":
        selected = st.selectbox("Column", ["All columns", *columns])
        if selected != "All columns":
            command["column"] = selected

    elif action == "remove_duplicates":
        selected_columns = st.multiselect(
            "Duplicate check columns",
            columns,
            default=columns,
        )
        if selected_columns:
            command["columns"] = selected_columns

    elif action == "format_report":
        st.caption("Applies header styling, filters, frozen panes, and column widths.")

    return command


def _parse_json_value(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return value


def _selected_sheet_columns(profile, sheet_name: str) -> list[str]:
    sheet_profile = next(item for item in profile.sheets if item.name == sheet_name)
    return sheet_profile.columns


PROMPT_SUGGESTIONS = [
    "Highlight students who still owe money",
    "Show students missing FAFSA",
    "Count active students by program",
    "Create a chart of enrollment by program",
    "Check this file for missing data",
    "Format this report",
]

HIGH_CONFIDENCE_THRESHOLD = 0.80
MEDIUM_CONFIDENCE_THRESHOLD = 0.60
CLARIFICATION_ACTIONS = {
    "filter rows": "filter_rows",
    "highlight rows": "highlight_rows",
    "create formula": "create_formula",
    "create chart": "create_chart",
    "create report": "create_report",
    "count/group data": "count_by_group",
    "format report": "format_report",
}
CLARIFICATION_OPERATORS = [
    "is_missing",
    "is_not_missing",
    "equals",
    "contains",
    "not_equals",
    "greater_than",
    "less_than",
    "greater_or_equal",
    "less_or_equal",
]


def initialize_ui_state() -> None:
    defaults: dict[str, Any] = {
        "chat_messages": [],
        "current_request": "",
        "current_command": {},
        "current_confirmation": None,
        "current_confidence": None,
        "current_source": None,
        "current_validation_error": None,
        "current_can_execute": False,
        "current_clarification": None,
        "current_confidence_level": None,
        "current_warning": None,
        "edit_command_mode": False,
        "show_correction_form": False,
        "action_history": [],
        "latest_output_file": None,
        "latest_result_preview": None,
        "latest_result_message": None,
        "latest_result_sheet": None,
        "assistant_mode": None,
        "current_plan": {},
        "assistant_memory": {},
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def render_product_styles() -> None:
    """Dark academic operations workspace.

    Near-black slate background, slate-800 cards, light text. Same calm,
    professional dean-office feel as the light theme but easier on the eyes
    for long sessions in a dim room.
    """
    st.markdown(
        """
        <style>
        /* Workspace background — slate-900 near-black */
        .stApp { background-color: #0B1220; color: #E2E8F0; }
        .block-container { padding-top: 1rem; max-width: 100%; }
        section[data-testid="stSidebar"] {
            background-color: #0F172A;
            border-right: 1px solid #1E293B;
        }
        section[data-testid="stSidebar"] * { color: #CBD5E1; }

        /* Base text color */
        body, .stMarkdown, .stMarkdown p, label, .stTextInput label,
        .stSelectbox label, .stCheckbox label {
            color: #E2E8F0 !important;
        }

        /* Card chrome — slate-800 cards on near-black background */
        [data-testid="stVerticalBlockBorderWrapper"] {
            background: #131C2E !important;
            border: 1px solid #1E293B !important;
            border-radius: 14px !important;
            padding: 16px 18px !important;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
            margin-bottom: 4px;
        }

        /* Card title + subtitle */
        .card-title {
            font-size: 1.02rem;
            font-weight: 700;
            color: #F1F5F9;
            margin-bottom: 2px;
            letter-spacing: 0.01em;
        }
        .card-subtitle {
            font-size: 0.82rem;
            color: #94A3B8;
            margin-bottom: 12px;
        }

        /* Headers — pale academic tone for contrast on dark */
        h1, h2, h3, h4 { color: #F1F5F9 !important; }
        h1 { font-size: 1.55rem !important; margin: 0 !important; }
        .app-tagline { color: #94A3B8; font-size: 0.9rem; margin-top: 2px; }

        /* Captions — muted slate */
        [data-testid="stCaptionContainer"], .stCaption { color: #94A3B8 !important; }

        /* Buttons — slate-800 outline, bright blue hover */
        .stButton button {
            background: #1E293B;
            color: #E2E8F0;
            border: 1px solid #334155;
            border-radius: 8px;
            font-weight: 500;
        }
        .stButton button:hover {
            background: #1E3A5F;
            border-color: #2563EB;
            color: #BFDBFE;
        }
        .stDownloadButton button {
            background: #2563EB;
            color: #FFFFFF;
            border: 1px solid #1D4ED8;
            border-radius: 8px;
            font-weight: 600;
        }
        .stDownloadButton button:hover { background: #1D4ED8; }

        /* Inputs — dark fill, light text */
        [data-baseweb="input"], [data-baseweb="select"] > div {
            background-color: #1E293B !important;
            border-radius: 8px;
        }
        [data-baseweb="input"] input,
        [data-baseweb="select"] div,
        textarea {
            color: #F1F5F9 !important;
        }
        [data-testid="stChatInput"] {
            background-color: #131C2E !important;
            border-radius: 10px;
        }
        [data-testid="stChatInput"] textarea {
            color: #F1F5F9 !important;
            background-color: transparent !important;
        }

        /* Status badges (single header strip) — dark-tinted */
        .status-strip {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 14px;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.25rem 0.65rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 600;
            border: 1px solid #334155;
            background: #1E293B;
            color: #E2E8F0;
            line-height: 1.2;
        }
        .badge-green  { background: rgba(34,197,94,0.12);  color: #4ADE80; border-color: rgba(34,197,94,0.40); }
        .badge-yellow { background: rgba(234,179,8,0.12);  color: #FBBF24; border-color: rgba(234,179,8,0.40); }
        .badge-red    { background: rgba(239,68,68,0.12);  color: #F87171; border-color: rgba(239,68,68,0.40); }
        .badge-gray   { background: #1E293B;                color: #94A3B8; border-color: #334155; }

        /* Empty-state — dashed dark card */
        .empty-state {
            border: 1px dashed #334155;
            border-radius: 12px;
            padding: 16px;
            color: #94A3B8;
            background: #0F172A;
            font-size: 0.9rem;
        }
        .empty-state strong { color: #F1F5F9; }
        .empty-state em { color: #BFDBFE; font-style: normal; }
        .empty-state ul { margin: 6px 0 0 18px; padding: 0; }
        .empty-state li { margin: 2px 0; color: #CBD5E1; }

        /* Metrics — light values, muted labels */
        [data-testid="stMetricValue"] { color: #F1F5F9 !important; }
        [data-testid="stMetricLabel"] { color: #94A3B8 !important; }

        /* Chat history bubbles — keep transparent so the card shows through */
        [data-testid="stContainer"] [data-testid="stChatMessage"] {
            background: transparent !important;
        }
        [data-testid="stChatMessage"] * { color: #E2E8F0; }

        /* Tables (dataframe) — dark rows, light text */
        [data-testid="stDataFrame"] { background: #131C2E; }
        [data-testid="stDataFrame"] * { color: #E2E8F0 !important; }

        /* Expander header */
        [data-testid="stExpander"] details summary {
            color: #F1F5F9;
        }
        [data-testid="stExpander"] details {
            background: #131C2E;
            border: 1px solid #1E293B;
            border-radius: 8px;
        }

        /* Tabs — slate styling */
        [data-baseweb="tab-list"] { background: transparent; }
        [data-baseweb="tab"] { color: #94A3B8 !important; }
        [data-baseweb="tab"][aria-selected="true"] {
            color: #BFDBFE !important;
            border-color: #2563EB !important;
        }

        /* File uploader — keep readable on dark */
        [data-testid="stFileUploader"] section {
            background-color: #1E293B !important;
            border: 1px dashed #334155 !important;
            border-radius: 10px;
            color: #CBD5E1 !important;
        }
        [data-testid="stFileUploader"] section * { color: #CBD5E1 !important; }
        [data-testid="stFileUploader"] button {
            background: #1E3A5F;
            color: #BFDBFE;
            border: 1px solid #334155;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def badge(label: str, tone: str = "gray") -> None:
    st.markdown(
        f'<span class="status-badge badge-{tone}">{label}</span>',
        unsafe_allow_html=True,
    )


from contextlib import contextmanager


@contextmanager
def render_card(title: str, subtitle: str | None = None):
    """Open a styled workspace card. Use as a context manager:

        with render_card("Original Workbook", "Read-only source of truth"):
            st.file_uploader(...)
    """
    container = st.container(border=True)
    with container:
        if title:
            st.markdown(f'<div class="card-title">{title}</div>',
                        unsafe_allow_html=True)
        if subtitle:
            st.markdown(f'<div class="card-subtitle">{subtitle}</div>',
                        unsafe_allow_html=True)
        yield container


def render_empty_state(text: str, suggestions: list[str] | None = None) -> None:
    """A subtle dashed-border empty state — replaces big blue st.info alerts."""
    body = f'<div class="empty-state"><strong>{text}</strong>'
    if suggestions:
        body += "<ul>" + "".join(f"<li>{s}</li>" for s in suggestions) + "</ul>"
    body += "</div>"
    st.markdown(body, unsafe_allow_html=True)


def confidence_tone(confidence: float | None) -> tuple[str, str]:
    if confidence is None:
        return "Not interpreted", "gray"
    if confidence >= HIGH_CONFIDENCE_THRESHOLD:
        return "High confidence", "green"
    if confidence >= MEDIUM_CONFIDENCE_THRESHOLD:
        return "Medium confidence", "yellow"
    return "Low confidence", "red"


def confidence_level(confidence: float | None) -> str:
    if confidence is None:
        return "none"
    if confidence >= HIGH_CONFIDENCE_THRESHOLD:
        return "high"
    if confidence >= MEDIUM_CONFIDENCE_THRESHOLD:
        return "medium"
    return "low"


def workbook_status(profile, diagnostics) -> tuple[str, str]:
    if profile is None:
        return "No file uploaded", "gray"
    has_columns = any(sheet.columns for sheet in profile.sheets)
    has_warnings = any(sheet.data_quality_warnings for sheet in diagnostics.sheets)
    if not has_columns:
        return "Needs column mapping", "yellow"
    if has_warnings:
        return "File loaded", "yellow"
    return "Ready", "green"


def selected_sheet_profile(profile, sheet_name: str):
    return next(item for item in profile.sheets if item.name == sheet_name)


def column_profile(dataframe) -> list[dict[str, Any]]:
    rows = []
    for column in dataframe.columns:
        series = dataframe[column]
        examples = [
            str(value)
            for value in series.dropna().astype(str).head(3).tolist()
            if str(value).strip()
        ]
        missing = int((series.isna() | (series.astype(str).str.strip() == "")).sum())
        rows.append(
            {
                "Column": str(column),
                "Inferred type": str(series.dtype),
                "Missing values": missing,
                "Example values": ", ".join(examples),
            }
        )
    return rows


def explain_command(command: dict[str, Any]) -> str:
    if not command:
        return "No command has been interpreted yet."
    if command.get("action") == "clarify":
        return command.get("question", "The request needs clarification.")
    return command_to_confirmation(command).replace(" Continue?", "")


def reset_current_interpretation() -> None:
    st.session_state["current_request"] = ""
    st.session_state["current_command"] = {}
    st.session_state["current_plan"] = {}
    st.session_state["assistant_mode"] = None
    st.session_state["current_confirmation"] = None
    st.session_state["current_confidence"] = None
    st.session_state["current_source"] = None
    st.session_state["current_validation_error"] = None
    st.session_state["current_can_execute"] = False
    st.session_state["current_clarification"] = None
    st.session_state["current_confidence_level"] = None
    st.session_state["current_warning"] = None
    st.session_state["edit_command_mode"] = False
    st.session_state["show_correction_form"] = False


def _learned_synonym_map() -> dict[str, list[str]]:
    learned = load_json("learned_synonyms.json")
    mapped: dict[str, list[str]] = {}
    if isinstance(learned, list):
        for item in learned:
            phrase = str(item.get("phrase", "")).strip()
            concept = str(item.get("mapped_concept", "")).strip()
            if phrase and concept:
                mapped.setdefault(concept, []).append(phrase)
    return mapped


def _synonyms_with_learned() -> dict[str, list[str]]:
    synonyms = load_json("synonyms.json")
    learned = _learned_synonym_map()
    for concept, phrases in learned.items():
        synonyms.setdefault(concept, [])
        synonyms[concept].extend(phrase for phrase in phrases if phrase not in synonyms[concept])
    return synonyms


def _fuzzy_phrase_in_text(phrase: str, text: str) -> bool:
    phrase_tokens = normalize_text(phrase).split()
    text_tokens = normalize_text(text).split()
    if not phrase_tokens or not text_tokens:
        return False

    for phrase_token in phrase_tokens:
        if phrase_token in text_tokens:
            continue
        if not any(SequenceMatcher(None, phrase_token, text_token).ratio() >= 0.78 for text_token in text_tokens):
            return False
    return True


def likely_action_label(command: dict[str, Any], request: str = "") -> str:
    action = command.get("action")
    reverse = {value: key for key, value in CLARIFICATION_ACTIONS.items()}
    if action in reverse:
        return reverse[action]

    text = normalize_text(request)
    if any(term in text for term in ["highlight", "mark", "color"]):
        return "highlight rows"
    if any(term in text for term in ["chart", "graph", "plot"]):
        return "create chart"
    if any(term in text for term in ["formula", "column that says", "flag"]):
        return "create formula"
    if any(term in text for term in ["report", "summary"]):
        return "create report"
    if any(term in text for term in ["count", "how many", "by"]):
        return "count/group data"
    if any(term in text for term in ["format", "clean"]):
        return "format report"
    return "filter rows"


def suggested_columns_for_request(request: str, columns: list[str], limit: int = 6) -> list[str]:
    if not columns:
        return ["Other"]

    suggestions: list[str] = []
    synonyms = _synonyms_with_learned()
    text = normalize_text(request)

    direct_column, direct_score = match_column_by_terms([request], columns)
    if direct_column and direct_score >= 0.35:
        suggestions.append(direct_column)

    for concept, phrases in synonyms.items():
        if (
            concept in text
            or any(normalize_text(phrase) in text for phrase in phrases)
            or any(_fuzzy_phrase_in_text(phrase, request) for phrase in phrases)
        ):
            column, score = match_column_for_concept(concept, columns, synonyms)
            if column and score >= 0.35:
                suggestions.append(column)

    request_tokens = set(text.split())
    scored_columns: list[tuple[float, str]] = []
    for column in columns:
        column_tokens = set(normalize_text(column).split())
        overlap = len(request_tokens & column_tokens)
        score = overlap / max(len(request_tokens | column_tokens), 1)
        if score > 0:
            scored_columns.append((score, column))

    for _, column in sorted(scored_columns, reverse=True):
        suggestions.append(column)

    unique = []
    for column in suggestions:
        if column not in unique:
            unique.append(column)
    for column in columns:
        if len(unique) >= limit:
            break
        if column not in unique:
            unique.append(column)

    return [*unique[:limit], "Other"]


def default_operator_and_value(request: str) -> tuple[str, str]:
    text = normalize_text(request)
    if any(term in text for term in ["missing", "blank", "empty", "didnt", "didn t", "not submitted", "not complete"]):
        return "is_missing", ""
    if any(term in text for term in ["owe", "owes", "owed", "balance due", "money due"]):
        return "greater_than", "0"
    if "active" in text:
        return "equals", "Active"
    if "inactive" in text:
        return "equals", "Inactive"
    if "withdrawn" in text:
        return "equals", "Withdrawn"
    return "contains", ""


def _condition_from_clarification(column: str, operator: str, raw_value: str) -> dict[str, Any]:
    condition: dict[str, Any] = {"column": column, "operator": operator}
    if operator not in OPERATORS_WITHOUT_VALUE:
        condition["value"] = _parse_json_value(raw_value) if raw_value.strip() else ""
    return condition


def build_clarified_command(
    *,
    request: str,
    action_label: str,
    sheet: str,
    column: str,
    operator: str,
    raw_value: str,
) -> dict[str, Any]:
    action = CLARIFICATION_ACTIONS[action_label]
    command: dict[str, Any] = {"action": action, "sheet": sheet}
    has_column = bool(column and column != "Other")

    if action in {"filter_rows", "highlight_rows"}:
        if has_column:
            command["conditions"] = [_condition_from_clarification(column, operator, raw_value)]
        if action == "highlight_rows":
            command["format"] = {"fill_color": "yellow"}
    elif action == "count_by_group":
        if has_column:
            if " by " in f" {normalize_text(request)} ":
                command["group_by"] = column
            else:
                command["action"] = "count_rows"
                command["conditions"] = [_condition_from_clarification(column, operator, raw_value)]
    elif action == "create_formula":
        if has_column:
            command.update(
                {
                    "new_column": f"{column} Flag",
                    "formula_type": "IF",
                    "logic": {
                        "condition_column": column,
                        "operator": operator,
                        "true_value": "Yes",
                        "false_value": "No",
                    },
                }
            )
            if operator not in OPERATORS_WITHOUT_VALUE:
                command["logic"]["value"] = _parse_json_value(raw_value) if raw_value.strip() else ""
    elif action == "create_chart":
        if has_column:
            command.update(
                {
                    "chart_type": "bar",
                    "group_by": column,
                    "metric": "count_rows",
                    "output_sheet": f"{column} Chart",
                    "title": f"{column} Chart",
                }
            )
    elif action == "create_report":
        command.update(
            {
                "report_type": "enrollment_summary",
                "include_summary": True,
                "include_chart": True,
                "output_sheet": "Clarified Report",
            }
        )
        if has_column:
            command["conditions"] = [_condition_from_clarification(column, operator, raw_value)]
    elif action == "format_report":
        pass

    return command


def save_clarified_request(
    *,
    request: str,
    incorrect_command: dict[str, Any],
    corrected_command: dict[str, Any],
    selected_column: str,
) -> None:
    if not request:
        return
    try:
        save_correction(
            request_id=None,
            original_request=request,
            incorrect_command=incorrect_command or {},
            corrected_command=corrected_command,
            correction_type="clarification",
            better_phrase=request,
            mapped_concept=selected_column if selected_column != "Other" else corrected_command.get("action"),
            raw_column_name=selected_column if selected_column != "Other" else None,
        )
    except Exception as exc:
        st.warning(f"Command rebuilt, but the local correction example could not be saved: {exc}")


def render_workbook_panel(uploaded_file, loaded, profile, diagnostics) -> str | None:
    st.subheader("Excel Workbook")
    uploaded_file = st.file_uploader(
        "Upload Excel workbook",
        type=["xlsx"],
        accept_multiple_files=False,
        key="workbook_upload",
    )

    if uploaded_file is None:
        badge("No file uploaded", "gray")
        st.info("Upload a `.xlsx` file to preview sheets and start asking questions.")
        return None

    if loaded is None or profile is None:
        return None

    status_label, status_tone = workbook_status(profile, diagnostics)
    badge(status_label, status_tone)
    st.write(f"File: `{profile.file_name}`")

    selected_sheet = st.selectbox(
        "Sheet",
        profile.sheet_names,
        key=f"sheet_selector_{profile.file_name}",
    )
    sheet_profile = selected_sheet_profile(profile, selected_sheet)
    dataframe = loaded.sheets[selected_sheet]

    metric_cols = st.columns(4)
    metric_cols[0].metric("Sheets", len(profile.sheet_names))
    metric_cols[1].metric("Rows", sheet_profile.row_count)
    metric_cols[2].metric("Columns", len(sheet_profile.columns))
    metric_cols[3].metric("Preview rows", min(len(dataframe.index), 100))

    st.write("Preview")
    st.dataframe(dataframe.head(100), use_container_width=True)

    with st.expander("Workbook metadata", expanded=False):
        st.write("Column names")
        if sheet_profile.columns:
            st.code("\n".join(sheet_profile.columns), language="text")
        else:
            st.info("No columns found on the selected sheet.")

    with st.expander("Column Profile", expanded=False):
        profile_rows = column_profile(dataframe)
        if profile_rows:
            st.dataframe(profile_rows, use_container_width=True, hide_index=True)
        else:
            st.info("No columns are available to profile.")

    with st.expander("Workbook Health Check", expanded=False):
        render_workbook_health_check(diagnostics)

    return selected_sheet


def render_result_preview() -> None:
    preview = st.session_state.get("latest_result_preview")
    if preview is not None:
        st.write("Latest result preview")
        st.dataframe(preview.head(50), use_container_width=True)


def render_download_latest() -> None:
    output_file = st.session_state.get("latest_output_file")
    if not output_file:
        return
    path = Path(output_file)
    if not path.exists():
        st.warning("The latest output file is no longer available.")
        return
    st.download_button(
        "Download latest edited Excel file",
        data=path.read_bytes(),
        file_name=path.name,
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        use_container_width=True,
    )


def run_current_action(
    *,
    loaded,
    current_user,
    permissions: dict[str, bool],
    privacy_settings: dict[str, Any],
) -> None:
    command = st.session_state.get("current_command") or {}
    plan = st.session_state.get("current_plan") or {}
    request = st.session_state.get("current_request", "")
    source = st.session_state.get("current_source")
    confidence = st.session_state.get("current_confidence")

    plan_commands = plan.get("commands") or ([command] if command else [])

    if not permissions["can_execute"]:
        st.error("Your role can preview and ask questions but cannot run actions.")
        return
    if not command and not plan_commands:
        st.error("No interpreted command is ready to run.")
        return
    if st.session_state.get("current_validation_error"):
        st.error("Resolve validation issues before running this action.")
        return
    if any(is_delete_row_action(step) for step in plan_commands) and privacy_settings["block_delete_row_actions"]:
        st.error("This row-removal action is blocked by the current safety settings.")
        return

    try:
        # Multi-step plans and planner-only actions run through execute_plan;
        # legacy single commands (clarification rebuilds, manual JSON) keep the
        # original single-command path.
        if plan.get("commands"):
            plan_result = execute_plan(plan, loaded.workbook, loaded.sheets, loaded.file_name)
            result = ActionResult(
                message=plan_result.message,
                preview=plan_result.preview,
                result_sheet=plan_result.result_sheet,
            )
        else:
            result = execute_command(command, loaded.workbook, loaded.sheets, loaded.file_name)
        export_path = export_edited_workbook(loaded.workbook, loaded.file_name)
        log_audit_event(
            username=current_user.username,
            user_role=current_user.role,
            action_type=command.get("action"),
            columns_affected=affected_columns(command),
            row_count_affected=affected_row_count(command, loaded.sheets),
            success=True,
            source=source,
        )
        st.session_state["latest_output_file"] = str(export_path)
        st.session_state["latest_result_preview"] = result.preview
        st.session_state["latest_result_message"] = result.message
        st.session_state["latest_result_sheet"] = result.result_sheet
        st.session_state.setdefault("export_history", []).insert(0, Path(export_path).name)
        action_name = command.get("action") if isinstance(command, dict) else None
        if action_name in {"create_chart", "create_report", "count_by_group", "summarize_missing"} and result.preview is not None:
            st.session_state.setdefault("figures_history", []).insert(
                0,
                {"sheet": result.result_sheet, "action": action_name, "preview": result.preview, "message": result.message},
            )
        st.session_state["action_history"].insert(
            0,
            {
                "request": request,
                "action": command.get("action"),
                "confidence": confidence,
                "success": True,
                "output": str(export_path),
            },
        )
        st.session_state["pending_feedback"] = {
            "file_name": loaded.file_name,
            "sheet_name": command.get("sheet"),
            "original_request": request,
            "command": command,
            "parser_confidence": confidence,
            "parser_source": source,
            "action_type": command.get("action"),
        }
        st.success(result.message)
    except Exception as exc:
        log_user_request(
            file_name=loaded.file_name,
            sheet_name=command.get("sheet") if isinstance(command, dict) else None,
            original_request=request,
            generated_command=command if isinstance(command, dict) else {},
            parser_confidence=confidence,
            parser_source=source,
            action_type=command.get("action") if isinstance(command, dict) else None,
            success=False,
            error_message=str(exc),
        )
        st.session_state["action_history"].insert(
            0,
            {
                "request": request,
                "action": command.get("action"),
                "confidence": confidence,
                "success": False,
                "output": "",
            },
        )
        st.error(f"Action failed: {exc}")


def render_clarification_panel(loaded, profile) -> None:
    request = st.session_state.get("current_request", "")
    original_command = st.session_state.get("current_command") or {}
    sheet_name = original_command.get("sheet") or profile.sheet_names[0]
    columns = _selected_sheet_columns(profile, sheet_name)
    likely_action = likely_action_label(original_command, request)
    column_options = suggested_columns_for_request(request, columns)
    default_operator, default_value = default_operator_and_value(request)

    st.warning("I need a little more information before I run anything.")
    with st.container(border=True):
        st.write("Help me understand your request.")
        st.caption(f"Detected intent: {likely_action if likely_action else 'Not sure yet'}")

        action_index = list(CLARIFICATION_ACTIONS).index(likely_action) if likely_action in CLARIFICATION_ACTIONS else 0
        action_label = st.selectbox(
            "What should I do?",
            list(CLARIFICATION_ACTIONS),
            index=action_index,
            key="clarify_action_label",
        )

        column_choice = st.selectbox(
            "Which column should I use?",
            column_options,
            key="clarify_column_choice",
        )
        if column_choice == "Other":
            selected_column = st.selectbox(
                "Choose a column",
                columns or ["Other"],
                key="clarify_other_column",
            )
        else:
            selected_column = column_choice

        operator_index = CLARIFICATION_OPERATORS.index(default_operator) if default_operator in CLARIFICATION_OPERATORS else 0
        operator = st.selectbox(
            "Condition",
            CLARIFICATION_OPERATORS,
            index=operator_index,
            key="clarify_operator",
        )

        raw_value = ""
        if operator not in OPERATORS_WITHOUT_VALUE:
            raw_value = st.text_input(
                "Value",
                value=default_value,
                key="clarify_value",
                placeholder="Example: Missing, Active, 0",
            )

        if st.button("Rebuild Command", type="primary", use_container_width=True):
            clarified = build_clarified_command(
                request=request,
                action_label=action_label,
                sheet=sheet_name,
                column=selected_column,
                operator=operator,
                raw_value=raw_value,
            )
            validation_error = None
            try:
                validate_command(clarified, loaded.sheets, loaded.file_name)
            except Exception as exc:
                validation_error = str(exc)

            if validation_error:
                st.session_state["current_command"] = clarified
                st.session_state["current_plan"] = {"plan_type": "single_action", "commands": [clarified]}
                st.session_state["current_validation_error"] = validation_error
                st.session_state["current_can_execute"] = False
            else:
                save_clarified_request(
                    request=request,
                    incorrect_command=original_command,
                    corrected_command=clarified,
                    selected_column=selected_column,
                )
                st.session_state["current_command"] = clarified
                st.session_state["current_plan"] = {"plan_type": "single_action", "commands": [clarified]}
                st.session_state["current_confirmation"] = command_to_confirmation(clarified)
                st.session_state["current_confidence"] = 0.90
                st.session_state["current_confidence_level"] = "high"
                st.session_state["current_source"] = "clarification"
                st.session_state["current_validation_error"] = None
                st.session_state["current_can_execute"] = True
                st.session_state["current_clarification"] = None
                st.session_state["current_warning"] = None
                st.session_state["medium_review_confirmed"] = False
                st.session_state["chat_messages"].append(
                    {
                        "role": "assistant",
                        "content": f"Thanks. I rebuilt the command using {selected_column}. Review it on the right before running.",
                    }
                )
            st.rerun()


def render_modifications_panel(loaded, profile, current_user, permissions, privacy_settings) -> None:
    """Right-top panel: the modification the assistant interpreted from the request,
    along with the run/cancel/correct controls. Excludes figures and exports — those
    live in their own panels."""
    st.subheader("Modifications")
    command = st.session_state.get("current_command") or {}
    confidence = st.session_state.get("current_confidence")
    level = st.session_state.get("current_confidence_level") or confidence_level(confidence)
    label, tone = confidence_tone(confidence)
    badge(label, tone)

    if not loaded:
        st.info("Upload a workbook and ask a question to see the interpreted action.")
        return

    if confidence is not None:
        st.metric("Confidence", f"{confidence:.0%}")
    if st.session_state.get("current_warning"):
        st.warning(st.session_state["current_warning"])

    plan = st.session_state.get("current_plan") or {}
    if plan.get("commands"):
        render_edit_plan_summary(plan)
    elif command:
        st.write("What the assistant understood")
        st.info(explain_command(command))
    else:
        st.caption("Ask a question on the left, then your modification will appear here.")

    validation_error = st.session_state.get("current_validation_error")
    if command:
        if validation_error:
            badge("Needs review", "red")
            st.error(validation_error)
        else:
            badge("Validated", "green")
            try:
                rows = affected_row_count(command, loaded.sheets)
            except Exception:
                rows = 0
            st.caption(f"Estimated affected rows: {rows}")
            if rows >= int(privacy_settings["warn_row_threshold"]):
                st.warning(f"This action may affect {rows} rows.")

        with st.expander("Generated JSON command", expanded=False):
            st.json(command)

        if level == "low":
            render_clarification_panel(loaded, profile)

        if st.session_state.get("edit_command_mode"):
            raw_command = st.text_area(
                "Edit command JSON",
                value=json.dumps(command, indent=2),
                height=260,
            )
            if st.button("Apply edited command", use_container_width=True):
                try:
                    edited = json.loads(raw_command)
                    validate_command(edited, loaded.sheets, loaded.file_name)
                except Exception as exc:
                    st.session_state["current_validation_error"] = str(exc)
                else:
                    st.session_state["current_command"] = edited
                    st.session_state["current_plan"] = {"plan_type": "single_action", "commands": [edited]}
                    st.session_state["current_confirmation"] = command_to_confirmation(edited)
                    st.session_state["current_confidence"] = 0.90
                    st.session_state["current_confidence_level"] = "high"
                    st.session_state["current_source"] = "manual_edit"
                    st.session_state["current_validation_error"] = None
                    st.session_state["current_can_execute"] = True
                    st.session_state["current_clarification"] = None
                    st.session_state["current_warning"] = None
                    st.session_state["edit_command_mode"] = False
                st.rerun()

        medium_confirmed = True
        if level == "medium":
            medium_confirmed = st.checkbox(
                "I reviewed this interpretation and want to allow running it.",
                key="medium_review_confirmed",
            )

        button_cols = st.columns(2)
        with button_cols[0]:
            if st.button(
                "Run Action",
                type="primary",
                use_container_width=True,
                disabled=(
                    bool(validation_error)
                    or not st.session_state.get("current_can_execute")
                    or level == "low"
                    or not medium_confirmed
                ),
            ):
                run_current_action(
                    loaded=loaded,
                    current_user=current_user,
                    permissions=permissions,
                    privacy_settings=privacy_settings,
                )
                st.rerun()
            if st.button("Edit Interpretation", use_container_width=True):
                st.session_state["edit_command_mode"] = True
                st.rerun()
        with button_cols[1]:
            if st.button("Correct Interpretation", use_container_width=True):
                st.session_state["show_correction_form"] = True
                st.rerun()
            if st.button("Cancel", use_container_width=True):
                reset_current_interpretation()
                st.rerun()

    latest_message = st.session_state.get("latest_result_message")
    if latest_message:
        st.success(latest_message)
        if st.session_state.get("latest_result_sheet"):
            st.caption(f"Result sheet: {st.session_state['latest_result_sheet']}")

    with st.expander("Session history", expanded=False):
        history = st.session_state.get("action_history", [])
        if not history:
            st.caption("No actions have run in this session.")
        else:
            st.dataframe(history[:10], use_container_width=True, hide_index=True)

    pending_feedback = st.session_state.get("pending_feedback")
    if pending_feedback and profile is not None:
        with st.expander("After-action feedback", expanded=False):
            feedback_sheet = pending_feedback.get("sheet_name") or profile.sheet_names[0]
            render_feedback_screen(
                pending_feedback,
                _selected_sheet_columns(profile, feedback_sheet),
            )


def _load_or_use_cache(uploaded_file):
    """Load the uploaded workbook once and cache it across reruns.

    Streamlit reruns the whole script on every interaction. Parsing the .xlsx on
    each rerun is what makes follow-up questions feel like the app 'froze' —
    and on flaky uploader state can also cause `loaded` to silently drop. We
    cache the LoadedWorkbook keyed by file name + byte length and only reparse
    when those change.
    """
    if uploaded_file is None:
        for key in ("cached_loaded", "cached_profile", "cached_diagnostics", "cached_load_key", "cached_load_error"):
            st.session_state.pop(key, None)
        return None, None, None, None

    try:
        file_name = getattr(uploaded_file, "name", "")
        file_bytes = uploaded_file.getvalue()
        cache_key = f"{file_name}:{len(file_bytes)}"
    except Exception:
        cache_key = None

    if cache_key and st.session_state.get("cached_load_key") == cache_key:
        return (
            st.session_state.get("cached_loaded"),
            st.session_state.get("cached_profile"),
            st.session_state.get("cached_diagnostics"),
            st.session_state.get("cached_load_error"),
        )

    # If the uploader's bytes are unavailable but we have a cached workbook from a
    # previous run, keep using it rather than dropping the user back to "no workbook."
    if cache_key is None and st.session_state.get("cached_loaded") is not None:
        return (
            st.session_state.get("cached_loaded"),
            st.session_state.get("cached_profile"),
            st.session_state.get("cached_diagnostics"),
            st.session_state.get("cached_load_error"),
        )

    loaded = None
    profile = None
    diagnostics = None
    load_error = None
    try:
        loaded = load_excel_workbook(uploaded_file)
        profile = profile_workbook(loaded.file_name, loaded.sheets)
        diagnostics = diagnose_workbook(loaded.workbook)
        if not profile.sheet_names:
            load_error = "No usable visible sheets were found in this workbook."
    except Exception as exc:
        load_error = f"Could not read this workbook: {exc}"

    st.session_state["cached_loaded"] = loaded
    st.session_state["cached_profile"] = profile
    st.session_state["cached_diagnostics"] = diagnostics
    st.session_state["cached_load_key"] = cache_key
    st.session_state["cached_load_error"] = load_error
    return loaded, profile, diagnostics, load_error


def main() -> None:
    initialize_database()
    sync_learning_files()
    initialize_ui_state()
    render_product_styles()

    current_user = require_login()
    if current_user is None:
        return

    uploaded_file = st.session_state.get("workbook_upload")
    roster_loaded, _profile_pre, diagnostics, load_error = _load_or_use_cache(uploaded_file)

    # Bind the roster to the per-session DataSourceRegistry, then re-derive an
    # enriched LoadedWorkbook (roster + attendance metrics + combined risk) so
    # every downstream component (chat, session workbook, suggestions, planner)
    # sees the same column-augmented view.
    registry = _ensure_data_source_registry(roster_loaded)
    _ingest_pending_attendance_upload(registry, roster_loaded)
    loaded, profile = _build_enriched_view(roster_loaded, registry)

    _maybe_reset_for_new_workbook(loaded)
    # Bind/refresh the session workbook to whatever is currently loaded. This
    # idempotently triggers reset_for_new_source on a different upload (v0.3
    # "reset only on new upload" contract); a no-op when the user re-uploads
    # the same file.
    ensure_session_workbook(loaded, profile)
    _maybe_post_upload_greeting(loaded, registry)

    privacy_settings = load_privacy_settings()

    with st.sidebar:
        permissions = render_user_bar(current_user)
        if loaded is not None:
            render_sidebar_resets(loaded, profile, "")
            render_sidebar_session_workbook()
        render_sidebar_failure_log()
        settings, privacy_settings, show_debug = render_sidebar_advanced(permissions, privacy_settings)

    if settings.get("strict_privacy_mode", True):
        settings = {**settings, "use_local_llm": False, "llm_explanations_enabled": False}

    st.markdown(
        '<h1>Dean Assistant</h1>'
        '<div class="app-tagline">Ask questions about an uploaded student workbook. '
        'All processing stays local.</div>',
        unsafe_allow_html=True,
    )
    render_status_badges(loaded, settings)

    if load_error:
        st.error(load_error)
        if diagnostics:
            render_workbook_health_check(diagnostics)

    # The active sheet (the one the chat planner runs queries against) is the
    # last source sheet the user picked. Generated and chart sheets are views
    # only — they never become the planner's target.
    active_sheet = ""
    if loaded is not None and profile is not None and profile.sheet_names:
        persisted = st.session_state.get(f"active_source_sheet_{profile.file_name}")
        active_sheet = persisted if persisted in profile.sheet_names else profile.sheet_names[0]

    if loaded is not None and active_sheet:
        _handle_inline_edit_actions(loaded, current_user, permissions, privacy_settings)

    # Two-panel workspace: chat on the left, unified workbook view on the
    # right (source sheets + LLM-generated sheets + chart sheets, all in one
    # picker — so results land inline with the source roster).
    chat_col, workbook_col = st.columns([0.32, 0.68], gap="medium")

    with chat_col:
        with render_card("Dean Assistant", "Ask questions about your roster."):
            render_chat_panel(
                loaded if active_sheet else None,
                profile if active_sheet else None,
                active_sheet,
                settings,
            )

    with workbook_col:
        with render_card("Data Sources", "Roster, attendance, assessments, and any results from the chat."):
            sheet_choice = render_data_sources_panel(
                loaded, profile, diagnostics, settings, registry,
            )
            if sheet_choice:
                active_sheet = sheet_choice
        working_title = (
            "Modified Working Sheet"
            if st.session_state.get("latest_output_file")
            else "Working Sheet"
        )
        with render_card(working_title, "Latest answer, confirmation, or edit plan."):
            render_live_output_panel(loaded, profile, active_sheet, settings)
        with render_card("Figures & Insights", "Charts generated from the active workbook."):
            render_figures_panel()

    with render_card("Export Center", "Downloads from this session."):
        render_export_center()

    pending_feedback = st.session_state.get("pending_feedback")
    if pending_feedback and profile is not None:
        with st.expander("After-action feedback", expanded=False):
            feedback_sheet = pending_feedback.get("sheet_name") or profile.sheet_names[0]
            render_feedback_screen(
                pending_feedback,
                _selected_sheet_columns(profile, feedback_sheet),
            )

    if loaded and show_debug:
        render_debug_panel(loaded, active_sheet)


def _ensure_data_source_registry(roster_loaded) -> DataSourceRegistry:
    """Return the per-session DataSourceRegistry, freshly created on first
    use and re-bound to the active roster on every rerun."""
    registry: DataSourceRegistry | None = st.session_state.get("data_source_registry")
    if registry is None:
        registry = DataSourceRegistry()
        st.session_state["data_source_registry"] = registry
    registry.risk_settings = load_risk_settings(st.session_state)
    registry.set_roster(roster_loaded)
    return registry


def _ingest_pending_attendance_upload(registry: DataSourceRegistry, roster_loaded) -> None:
    """If the user uploaded a new attendance file this rerun, parse it,
    match against the roster, and bind to the registry.

    We compare upload bytes to a cached key so a rerun without a new upload
    is a no-op (and so re-uploading the same file is also a no-op).
    """
    uploaded = st.session_state.get("attendance_upload")
    if uploaded is None:
        return
    if roster_loaded is None:
        # No roster yet → don't parse attendance (can't match Student IDs).
        return
    try:
        cache_key = f"{getattr(uploaded, 'name', '')}:{len(uploaded.getvalue())}"
    except Exception:
        cache_key = None
    if cache_key and st.session_state.get("attendance_cache_key") == cache_key:
        return
    try:
        loaded_attendance = load_attendance_file(uploaded)
    except Exception as exc:
        st.session_state["attendance_load_error"] = (
            f"Could not read the attendance file: {exc}"
        )
        return
    st.session_state["attendance_load_error"] = None
    target_sheet = registry.enriched_roster_sheet
    roster_frame = roster_loaded.sheets.get(target_sheet) if target_sheet else None
    matched, unmatched, unmatched_ids = (0, 0, [])
    if roster_frame is not None:
        matched, unmatched, unmatched_ids = match_attendance_to_roster(
            loaded_attendance.frame, roster_frame,
        )
    registry.set_attendance(AttendanceSource(
        file_name=loaded_attendance.file_name,
        frame=loaded_attendance.frame,
        matched_count=matched,
        unmatched_count=unmatched,
        unmatched_ids=unmatched_ids,
        warnings=loaded_attendance.warnings,
    ))
    st.session_state["attendance_cache_key"] = cache_key


def _build_enriched_view(
    roster_loaded, registry: DataSourceRegistry,
) -> tuple[Any | None, Any | None]:
    """Re-derive a (LoadedWorkbook, WorkbookProfile) pair whose sheets dict
    includes attendance metrics + combined-risk columns merged onto the
    roster. Returns (None, None) when no roster is loaded.
    """
    if roster_loaded is None:
        return None, None
    enriched_sheets = registry.enriched_sheets() or dict(roster_loaded.sheets)
    enriched_loaded = LoadedWorkbook(
        file_name=roster_loaded.file_name,
        workbook=roster_loaded.workbook,
        sheets=enriched_sheets,
        warnings=list(roster_loaded.warnings or []),
    )
    enriched_profile = profile_workbook(enriched_loaded.file_name, enriched_sheets)
    return enriched_loaded, enriched_profile


def render_data_sources_panel(
    loaded, profile, diagnostics, settings, registry: DataSourceRegistry,
) -> str | None:
    """Right-panel renderer. Tabs: Roster / Attendance / Assessments / Results.

    Returns the active *roster* sheet name so the caller can use it as the
    chat planner's target. Generated / chart sheets live in the Results tab
    (they're views only; the planner stays on the roster).
    """
    tabs = st.tabs(["Academic Workbook", "Attendance", "Assessments", "Results"])
    active_sheet: str | None = None
    with tabs[0]:
        active_sheet = _render_roster_tab(loaded, profile, registry)
    with tabs[1]:
        _render_attendance_tab(registry)
    with tabs[2]:
        _render_assessments_tab(registry)
    with tabs[3]:
        _render_results_tab(loaded, profile, diagnostics, settings)
    return active_sheet


def _render_roster_tab(loaded, profile, registry: DataSourceRegistry | None = None) -> str | None:
    """Academic Workbook tab — capability-first layout.

    Display order (capabilities first; raw schema last and collapsed):
      1. File header + protection badges + attendance badge.
      2. Detected capabilities checklist.
      3. Detected fields, grouped (Roster / Performance / Attendance / Actions / Export).
      4. Missing-field helpful notes.
      5. Raw sheet preview (collapsed expander — for verifying the actual data).
    """
    st.file_uploader(
        "Upload academic workbook .xlsx",
        type=["xlsx"],
        accept_multiple_files=False,
        key="workbook_upload",
        help=("One file. The assistant detects roster columns and attendance "
              "data (inline columns or a sibling Attendance sheet) "
              "automatically. The original file is never modified."),
    )
    if loaded is None or profile is None or not profile.sheet_names:
        render_empty_state(
            "No workbook loaded.",
            suggestions=["Upload an .xlsx workbook to begin.",
                         "I'll detect teacher, department, GPA, academic "
                         "standing — and attendance if it's present."],
        )
        return None

    persist_key = f"active_source_sheet_{profile.file_name}"
    options = list(profile.sheet_names)
    default = st.session_state.get(persist_key)
    if default not in options:
        default = options[0]
    if len(options) > 1:
        active = st.selectbox(
            "Roster sheet", options,
            index=options.index(default), key=f"roster_sheet_{profile.file_name}",
        )
    else:
        active = options[0]
    st.session_state[persist_key] = active

    sheet_profile = next(item for item in profile.sheets if item.name == active)

    # 1. Header — file name + sheet + counts in school-office wording.
    st.markdown(
        f"**Academic Workbook Loaded**  \n"
        f"`{profile.file_name}`  \n"
        f"{active} sheet · {sheet_profile.row_count} students · "
        f"{len(sheet_profile.columns)} columns"
    )
    badge_cols = st.columns(3)
    with badge_cols[0]:
        badge("Original workbook protected", "green")
    with badge_cols[1]:
        badge("Read-only source", "green")
    with badge_cols[2]:
        if registry is not None and registry.attendance_available():
            badge("Attendance available", "green")
        else:
            badge("No attendance fields detected", "yellow")

    # 2 + 3 + 4. Capabilities, detected fields, missing notes.
    attendance_available = bool(registry is not None and registry.attendance_available())
    _render_capability_summary(
        sheet_profile.columns,
        attendance_available,
        frame=loaded.sheets.get(active),
    )

    # 5. The raw sheet — useful for verifying the actual rows, but it's NOT
    # the first thing the user sees. Collapsed by default.
    with st.expander("View the full sheet", expanded=False):
        _render_source_sheet_full(loaded, profile, active)
    return active


def _render_capability_summary(columns: list[str], attendance_available: bool, frame=None) -> None:
    """Render the Detected Capabilities checklist + Detected Fields blocks +
    helpful missing-field notes. Pure presentation — all logic lives in
    ``core.workbook_capabilities``."""
    from core.workbook_capabilities import (
        CATEGORY_ORDER,
        detect_capabilities,
        group_detected_fields,
        missing_field_messages,
    )

    mode = InstitutionMode.from_label(st.session_state.get("institution_mode", InstitutionMode.GENERIC.value))
    caps = detect_capabilities(columns, attendance_available=attendance_available, mode=mode)
    grouped = group_detected_fields(columns)
    messages = missing_field_messages(columns, attendance_available=attendance_available, mode=mode)

    st.markdown("#### Detected Capabilities")
    available_caps = [c for c in caps if c.available]
    unavailable_caps = [c for c in caps if not c.available]
    for cap in available_caps:
        if cap.note:
            st.markdown(f"✓ **{cap.title}** — {cap.note}")
        else:
            st.markdown(f"✓ **{cap.title}**")
    for cap in unavailable_caps:
        st.markdown(
            f"<span style='opacity:0.55;'>○ {cap.title}"
            f"{f' — {cap.note}' if cap.note else ''}</span>",
            unsafe_allow_html=True,
        )

    st.markdown("#### Detected Fields")
    has_any = False
    for category in CATEGORY_ORDER:
        labels = grouped.get(category) or []
        if not labels:
            continue
        has_any = True
        st.markdown(f"**{category}:** {' · '.join(labels)}")
    if not has_any:
        st.caption("No recognised academic fields yet.")

    if messages:
        with st.expander(f"Notes on missing fields ({len(messages)})", expanded=False):
            for note in messages:
                st.markdown(f"• {note}")
    with st.expander("Workbook Readiness", expanded=False):
        from core.workbook_capabilities import readiness_checks, readiness_issues
        for label, status in readiness_checks(columns):
            symbol = "✓" if status == "found" else ("⚠" if status == "issue found" else "○")
            st.markdown(f"{symbol} {label}: {status}")
        for issue in readiness_issues(frame if frame is not None else columns):
            st.markdown(f"⚠ {issue}")
    with st.expander("Workflow Templates", expanded=False):
        from core.institution_context import workflow_templates, role_prompt_snippets
        role = Role.from_label(st.session_state.get("user_role", Role.ADMIN.value))
        for title, body in workflow_templates(mode):
            st.markdown(f"**{title}**")
            st.caption(body)
        st.caption("Suggested workflow focus: " + ", ".join(role_prompt_snippets(role, mode)))




def _render_attendance_tab(registry: DataSourceRegistry) -> None:
    """Attendance status panel.

    Leads with whichever attendance source was auto-detected inside the
    uploaded workbook (inline columns or a sibling sheet). Falls back to a
    friendly "no attendance" state for roster-only workbooks. The external
    attendance uploader is kept as an Advanced expander — it's the right
    tool when a school exports daily attendance as a separate file but
    should NOT be the primary path the user has to find.
    """
    if registry.roster is None:
        render_empty_state(
            "Upload a roster first.",
            suggestions=["Attendance is detected automatically when the workbook "
                         "carries it (inline columns or a sibling Attendance sheet)."],
        )
        return

    summary = registry.summary()
    detection = summary.get("workbook_attendance") or {}
    mode = detection.get("mode", "none")

    if registry.attendance is not None:
        # External upload (Advanced) is the active source.
        badge("Attendance available · external file", "green")
    elif mode == "inline":
        badge("Attendance available · workbook columns", "green")
    elif mode == "sheet":
        badge(f"Attendance available · workbook sheet ‘{detection.get('attendance_sheet')}’",
              "green")
    else:
        badge("No attendance fields detected", "yellow")

    if mode == "inline":
        cols = detection.get("inline_columns") or []
        st.caption(
            f"Detected attendance columns on the roster: {', '.join(cols)}."
        )
    elif mode == "sheet":
        sheet_name = detection.get("attendance_sheet")
        st.caption(
            f"Detected sibling sheet **{sheet_name}** — attendance metrics "
            "are computed and merged into the roster automatically."
        )
    elif registry.attendance is None:
        st.markdown(
            "I do not see attendance data in this workbook. I can still help "
            "with GPA, academic standing, teacher, department, and Academic "
            "Watch workflows. If you have a separate daily-attendance file, "
            "you can load it under **Advanced** below."
        )

    if registry.attendance is not None:
        info = summary.get("attendance") or {}
        metric_cols = st.columns(3)
        metric_cols[0].metric("Attendance rows", info.get("rows", 0))
        metric_cols[1].metric("Matched students", info.get("matched", 0))
        metric_cols[2].metric("Unmatched IDs", info.get("unmatched", 0))
        st.caption(
            f"**{info.get('file_name', '')}** · "
            f"{info.get('rows', 0)} rows · {len(info.get('columns') or [])} columns"
        )
        unmatched_sample = info.get("unmatched_sample") or []
        if unmatched_sample:
            st.warning(
                "Some Student IDs in the attendance file don't appear in the roster: "
                + ", ".join(unmatched_sample)
                + (" …" if (info.get("unmatched", 0) > len(unmatched_sample)) else "")
            )
        for note in info.get("warnings") or []:
            st.caption(f"• {note}")
        if not registry.attendance.frame.empty:
            st.dataframe(registry.attendance.frame.head(200),
                         use_container_width=True, hide_index=True, height=240)

    with st.expander("Advanced: load a separate attendance file", expanded=False):
        st.caption(
            "Use this only when the daily attendance file is separate from "
            "the academic workbook. An external file takes priority over "
            "anything auto-detected inside the workbook."
        )
        st.file_uploader(
            "Upload attendance .xlsx",
            type=["xlsx"],
            accept_multiple_files=False,
            key="attendance_upload",
            help="Long-format: one row per (Student ID, Date). Matched on Student ID.",
        )
        load_error = st.session_state.get("attendance_load_error")
        if load_error:
            st.error(load_error)


def _render_assessments_tab(registry: DataSourceRegistry) -> None:
    """Stub — PSAT/SAT ingestion is deferred behind attendance (Phase F)."""
    render_empty_state(
        "Assessment ingestion is not yet wired up.",
        suggestions=[
            "PSAT/SAT support is the next slice (after attendance is fully validated).",
            "Schema and field list are stubbed in core/assessment.py.",
        ],
    )


def _render_results_tab(loaded, profile, diagnostics, settings) -> None:
    """Generated session sheets + chart sheets (the previous unified view)."""
    render_unified_workbook_panel(loaded, profile, diagnostics, settings,
                                  hide_uploader=True, hide_source_sheets=True)


def render_unified_workbook_panel(loaded, profile, diagnostics, settings,
                                  *, hide_uploader: bool = False,
                                  hide_source_sheets: bool = False) -> str | None:
    """Single workbook view that lists source sheets, generated session
    sheets, and chart sheets in one picker. Returns the active *source* sheet
    name — the planner always operates on a source sheet, even when the user
    is currently viewing a generated or chart sheet.
    """
    if not hide_uploader:
        st.file_uploader(
            "Upload .xlsx roster",
            type=["xlsx"],
            accept_multiple_files=False,
            key="workbook_upload",
            help="The original workbook is never modified.",
        )
    if loaded is None or profile is None or not profile.sheet_names:
        render_empty_state(
            "No workbook loaded.",
            suggestions=["Upload an .xlsx roster to begin.",
                         "Examples: students, advisors, GPA, standing."],
        )
        return None

    if hide_source_sheets:
        source_options: list[tuple[str, str, str]] = []
    else:
        source_options = [("source", name, name) for name in profile.sheet_names]

    workbook = st.session_state.get("session_workbook")
    generated_options: list[tuple[str, str, str]] = []
    if workbook is not None:
        for record in workbook.sheets:
            generated_options.append(("generated", record.name, f"Generated · {record.name}"))

    figures_history = st.session_state.get("figures_history") or []
    figure_options: list[tuple[str, str, str]] = []
    for idx, fig in enumerate(figures_history):
        title = fig.get("title") or f"Chart {idx + 1}"
        figure_options.append(("figure", str(idx), f"Chart · {title}"))

    all_options = source_options + generated_options + figure_options
    labels = [opt[2] for opt in all_options]
    if not labels:
        # Results tab with nothing generated yet — friendly empty state.
        render_empty_state(
            "No results yet.",
            suggestions=["Ask the assistant a question to create a generated sheet.",
                         "Charts the assistant builds will also appear here."],
        )
        return None

    # Auto-jump: the most recent chat turn or chart can request a specific
    # view via _pending_view_sheet. Consume it once so subsequent reruns
    # leave the user where they last clicked.
    pending = st.session_state.pop("_pending_view_sheet", None)
    selector_key = f"unified_view_{profile.file_name}"

    target_label: str | None = None
    if pending:
        kind, key = pending
        for opt in all_options:
            if opt[0] == kind and opt[1] == key:
                target_label = opt[2]
                break
    existing = st.session_state.get(selector_key)
    if target_label is None and existing in labels:
        target_label = existing
    if target_label is None:
        target_label = labels[0]
    st.session_state[selector_key] = target_label

    selected_label = st.selectbox(
        "View",
        labels,
        key=selector_key,
        help="Switch between the uploaded sheets, results created by the assistant, and chart sheets.",
    )
    selected_kind, selected_key, _ = all_options[labels.index(selected_label)]

    # Persist the last-picked source sheet for the chat planner. When the
    # user is viewing a generated/chart sheet, the planner stays on whatever
    # source sheet they were last on.
    persist_key = f"active_source_sheet_{profile.file_name}"
    if selected_kind == "source":
        st.session_state[persist_key] = selected_key
        active_source = selected_key
    else:
        active_source = st.session_state.get(persist_key) or profile.sheet_names[0]

    if selected_kind == "source":
        _render_source_sheet_full(loaded, profile, active_source)
    elif selected_kind == "generated":
        _render_generated_sheet(workbook, selected_key)
    elif selected_kind == "figure":
        _render_chart_sheet(figures_history, int(selected_key))

    warnings = list(getattr(loaded, "warnings", None) or [])
    with st.expander(f"Workbook notes ({len(warnings)})", expanded=False):
        if warnings:
            for note in warnings:
                st.caption(f"• {note}")
        else:
            st.caption("No loader warnings.")
    return active_source


def _render_source_sheet_full(loaded, profile, sheet_name: str) -> None:
    """Full sheet view of the uploaded workbook (no 5-row preview limit).

    Sensitive columns are still hidden by default per core.privacy, matching
    the redact_table behavior used in the old preview.
    """
    import pandas as pd
    from core.privacy import redact_table

    sheet_profile = next((item for item in profile.sheets if item.name == sheet_name), None)
    if sheet_profile is None:
        st.caption(f"Sheet '{sheet_name}' is not in the loaded workbook.")
        return

    cols = st.columns(3)
    cols[0].metric("Rows", sheet_profile.row_count)
    cols[1].metric("Columns", len(sheet_profile.columns))
    cols[2].metric("Sheets", len(profile.sheet_names))

    badge_cols = st.columns(2)
    with badge_cols[0]:
        badge("Original file protected", "green")
    with badge_cols[1]:
        badge("Read-only", "green")

    st.caption(
        f"**{profile.file_name}** · {sheet_name} · "
        f"{sheet_profile.row_count} rows · {len(sheet_profile.columns)} columns"
    )

    frame = loaded.sheets.get(sheet_name)
    if frame is None or frame.empty:
        st.caption("This sheet has no rows.")
        return

    rows = frame.to_dict(orient="records")
    redacted_rows, hidden = redact_table(rows, list(frame.columns))
    if hidden:
        st.caption(f"Sensitive columns hidden by default: {', '.join(hidden)}")
    st.dataframe(
        pd.DataFrame(redacted_rows) if redacted_rows else frame,
        use_container_width=True,
        hide_index=True,
        height=520,
    )


def _render_generated_sheet(workbook, sheet_name: str) -> None:
    """Render a sheet produced by a chat turn (filter, sort, aggregate)."""
    import pandas as pd

    if workbook is None:
        render_empty_state("No generated sheets yet.")
        return
    record = next((s for s in workbook.sheets if s.name == sheet_name), None)
    if record is None:
        st.caption(f"Generated sheet '{sheet_name}' is no longer in this session.")
        return

    badge("Generated by the assistant", "blue")
    if record.user_message:
        st.caption(f"From: {record.user_message}")
    if record.conclusion:
        st.markdown(f"**Conclusion:** {record.conclusion}")
    if record.sensitive_redacted:
        st.caption(f"Sensitive columns hidden by default: {', '.join(record.sensitive_redacted)}")

    if record.data:
        frame = pd.DataFrame(record.data)
        st.dataframe(frame, use_container_width=True, hide_index=True, height=520)
        st.download_button(
            "Download this sheet (CSV)",
            data=frame.to_csv(index=False).encode("utf-8"),
            file_name=f"{sheet_name}.csv",
            mime="text/csv",
            use_container_width=True,
            key=f"dl_generated_{sheet_name}",
        )
    else:
        st.caption("No rows in this generated sheet.")


def _render_chart_sheet(figures_history, index: int) -> None:
    """Render a chart sheet — the altair chart plus its summary table."""
    import pandas as pd

    if not figures_history or index < 0 or index >= len(figures_history):
        render_empty_state("That chart is no longer available.")
        return
    fig = figures_history[index]

    badge("Chart sheet", "blue")
    title = fig.get("title") or "Chart"
    st.markdown(f"**{title}**")

    preview = fig.get("preview")
    summary = preview if isinstance(preview, pd.DataFrame) else pd.DataFrame(preview or [])
    if summary.empty:
        st.caption("No data for this chart.")
        return

    intent = ChartIntent(
        chart_type=str(fig.get("type", "bar")),
        field=str(fig.get("field", "")),
        metric=str(fig.get("metric", "count")),
        value_column=str(fig.get("value_column", "")),
    )
    chart = build_altair_chart(intent, summary, title)
    st.altair_chart(chart, use_container_width=True)
    st.dataframe(summary, use_container_width=True, hide_index=True)
    st.download_button(
        "Download chart data (CSV)",
        data=summary.to_csv(index=False).encode("utf-8"),
        file_name=f"chart_{index}.csv",
        mime="text/csv",
        use_container_width=True,
        key=f"dl_chart_{index}",
    )


def render_export_center() -> None:
    """Bottom-right card content (title supplied by render_card wrapper)."""
    output_file = st.session_state.get("latest_output_file")
    figure = st.session_state.get("latest_figure")
    history = st.session_state.get("export_history") or []

    if not output_file and not figure and not history:
        render_empty_state(
            "No exports yet.",
            suggestions=["Exports and modified workbooks will appear here.",
                         "Ask the assistant to export this list."],
        )
        return

    if output_file:
        path = Path(output_file)
        if path.exists():
            st.download_button(
                "Download edited workbook (.xlsx)",
                data=path.read_bytes(),
                file_name=path.name,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
                key="export_workbook",
            )
        else:
            st.caption("The latest workbook output is no longer available.")

    # Latest result CSV
    latest_result_attachment = _latest_result_attachment()
    if latest_result_attachment and latest_result_attachment.get("table"):
        import pandas as pd

        frame = pd.DataFrame(latest_result_attachment["table"])
        st.download_button(
            "Download latest result (CSV)",
            data=frame.to_csv(index=False).encode("utf-8"),
            file_name="latest_result.csv",
            mime="text/csv",
            use_container_width=True,
            key="export_result_csv",
        )

    if figure:
        figure_csv = export_latest_figure_csv()
        if figure_csv is not None:
            file_name, payload = figure_csv
            st.download_button(
                f"Latest figure data (CSV): {figure.get('field', 'figure')}",
                data=payload,
                file_name=file_name,
                mime="text/csv",
                use_container_width=True,
                key="export_figure_csv",
            )

    if history:
        st.caption("Session outputs:")
        for entry in history[:8]:
            st.caption(f"• {entry}")


def _latest_result_attachment() -> dict[str, Any] | None:
    messages = st.session_state.get("chat_messages") or []
    for index in range(len(messages) - 1, -1, -1):
        attachment = messages[index].get("attachment") or {}
        if attachment.get("type") == "result":
            return attachment
    return None


def render_sidebar_workbook(loaded, profile) -> str | None:
    """Sidebar: file uploader plus a compact workbook summary."""
    st.markdown("### Workbook")
    st.file_uploader(
        "Upload Excel workbook",
        type=["xlsx"],
        accept_multiple_files=False,
        key="workbook_upload",
    )
    if loaded is None or profile is None or not profile.sheet_names:
        st.caption("No workbook loaded yet.")
        return None

    selected_sheet = st.selectbox(
        "Sheet",
        profile.sheet_names,
        key=f"sheet_selector_{profile.file_name}",
    )
    sheet_profile = next(item for item in profile.sheets if item.name == selected_sheet)
    st.caption(f"**{profile.file_name}**")
    st.caption(f"{selected_sheet} · {sheet_profile.row_count} rows · {len(sheet_profile.columns)} columns")

    warnings = getattr(loaded, "warnings", None)
    if warnings:
        with st.expander(f"Workbook notes ({len(warnings)})", expanded=False):
            for note in warnings:
                st.caption(f"• {note}")
    return selected_sheet


def render_sidebar_resets(loaded, profile, selected_sheet: str) -> None:
    """Sidebar buttons for Clear filters and Start over.

    Clear filters keeps the chat history; Start over wipes the conversation
    state but keeps the uploaded workbook so the user can begin a fresh thread.
    """
    st.markdown("### Conversation")
    cols = st.columns(2)
    if cols[0].button("Clear filters", key="side_clear", use_container_width=True):
        from ui.chat_panel import route_message  # avoid circular at module load

        route_message(
            request="clear that",
            selected_sheet=selected_sheet,
            loaded=loaded,
            profile=profile,
            settings={"strict_privacy_mode": True},
        )
        st.rerun()
    if cols[1].button("Start over", key="side_reset", use_container_width=True):
        _start_over_keep_workbook()
        st.rerun()


def render_sidebar_session_workbook() -> None:
    """Sidebar panel for the accumulating session workbook (v0.3).

    Shows the sheets recorded so far, a download button for the .xlsx, a
    suppress-last-turn action ([Don't save this]), and an explicit
    'Start new investigation' button that opens a fresh workbook.
    """
    workbook = st.session_state.get("session_workbook")
    if workbook is None:
        return

    st.markdown("### Session workbook")
    sheets = workbook.list_sheets()
    if not sheets:
        st.caption("No investigations recorded yet. Each question you ask becomes a sheet in this workbook.")
    else:
        st.caption(f"{len(sheets)} sheet{'s' if len(sheets) != 1 else ''} · `{workbook.path.name}`")
        for index, entry in enumerate(sheets, start=1):
            st.caption(f"{index}. {entry['name']} — {entry['row_count']} row{'s' if entry['row_count'] != 1 else ''}")

    cols = st.columns(2)
    download_disabled = not sheets or not workbook.path.exists()
    if download_disabled:
        cols[0].button("Download", key="sw_download", disabled=True, use_container_width=True)
    else:
        try:
            payload = workbook.path.read_bytes()
        except OSError:
            payload = b""
        cols[0].download_button(
            label="Download",
            data=payload,
            file_name=workbook.path.name,
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="sw_download",
            use_container_width=True,
            disabled=not payload,
        )

    if cols[1].button("Don't save last", key="sw_suppress", disabled=not sheets,
                      use_container_width=True):
        if workbook.suppress_last_turn():
            st.toast("Removed the most recent sheet.")
        st.rerun()

    if st.button("Start new investigation", key="sw_new_investigation",
                 use_container_width=True, disabled=not sheets):
        workbook.reset_for_new_source(
            source_file_name=workbook.source_file_name,
            schema_hash=workbook.schema_hash,
        )
        st.toast("Started a fresh session workbook.")
        st.rerun()


def render_sidebar_failure_log() -> None:
    """Show recent asks the assistant couldn't handle.

    Each entry has a timestamp, the user's exact message, and a one-line
    reason. The point isn't to apologize to the user — it's to give the
    developer (us) a triage queue when iterating on rule coverage.
    """
    from core.failure_log import clear_failures, read_failures

    recent = read_failures(limit=25)
    label = f"Things I couldn't answer ({len(recent)})" if recent else "Things I couldn't answer"
    with st.expander(label, expanded=False):
        if not recent:
            st.caption("No failed asks recorded yet.")
            return
        st.caption(
            "Every clarify / unsupported / failed query lands here so we can "
            "see what real phrasings the planner still needs to learn."
        )
        for entry in recent[:10]:
            ts = (entry.get("timestamp") or "").replace("T", " ")
            intent = entry.get("intent") or "?"
            message = (entry.get("user_message") or "").strip()
            reason = (entry.get("reason") or "").strip()
            sheet = entry.get("sheet") or ""
            st.markdown(
                f"**{message or '(empty)'}**\n\n"
                f"<span style='font-size:0.78rem; opacity:0.65;'>"
                f"{ts} · {intent}{f' · {sheet}' if sheet else ''}</span>",
                unsafe_allow_html=True,
            )
            if reason:
                st.caption(reason[:160] + ("…" if len(reason) > 160 else ""))
            st.divider()
        if st.button("Clear failure log", key="failure_log_clear",
                     use_container_width=True):
            clear_failures()
            st.toast("Failure log cleared.")
            st.rerun()


def _start_over_keep_workbook() -> None:
    """Wipe conversation state but keep the uploaded workbook + cached load."""
    st.session_state["chat_messages"] = []
    st.session_state["assistant_memory"] = {}
    st.session_state["assistant_mode"] = None
    st.session_state["current_command"] = {}
    st.session_state["current_plan"] = {}
    st.session_state["current_confirmation"] = None
    st.session_state["current_confidence"] = None
    st.session_state["current_source"] = None
    st.session_state["current_validation_error"] = None
    st.session_state["current_can_execute"] = False
    st.session_state["current_clarification"] = None
    st.session_state["current_warning"] = None
    st.session_state["latest_output_file"] = None
    st.session_state["latest_result_preview"] = None
    st.session_state["latest_result_message"] = None
    st.session_state["latest_result_sheet"] = None
    st.session_state["figures_history"] = []
    st.session_state["action_history"] = []
    st.session_state["export_history"] = []
    st.session_state["latest_figure"] = None
    st.session_state["routing_debug"] = None
    st.session_state["pending_feedback"] = None
    for key in (
        "ask_question",
        "ask_operation",
        "ask_description",
        "ask_explanation",
        "ask_value",
        "ask_row_count",
        "ask_table",
        "ask_columns_used",
        "ask_confidence",
        "ask_source",
        "ask_preview_truncated",
        "ask_redacted",
        "ask_review_note",
        "clarify_question",
        "clarify_reason",
        "clarify_options",
    ):
        st.session_state.pop(key, None)


def _maybe_reset_for_new_workbook(loaded) -> None:
    """If the user uploaded a different workbook than the previous run, treat it
    as the start of a fresh conversation (J.7 'New workbook upload')."""
    file_name = getattr(loaded, "file_name", None) if loaded is not None else None
    previous = st.session_state.get("_last_loaded_file_name")
    if file_name == previous:
        return
    st.session_state["_last_loaded_file_name"] = file_name
    if file_name is None or previous is None:
        # Initial load or workbook removal — don't wipe a fresh user's empty chat.
        if previous is not None:
            _start_over_keep_workbook()
        return
    _start_over_keep_workbook()


def _maybe_post_upload_greeting(loaded, registry) -> None:
    """Append ONE assistant greeting per uploaded workbook.

    Keyed by ``loaded.file_name`` so Streamlit's per-interaction reruns
    don't keep prepending the same greeting; a different upload resets
    the key (via ``_maybe_reset_for_new_workbook`` clearing chat first).
    """
    if loaded is None or registry is None or registry.roster is None:
        return
    from core.workbook_capabilities import upload_assistant_message

    file_name = getattr(loaded, "file_name", "") or ""
    already_greeted = st.session_state.get("_greeted_workbook")
    if already_greeted == file_name:
        return
    sheet = registry.enriched_roster_sheet or ""
    frame = loaded.sheets.get(sheet)
    columns = list(frame.columns) if frame is not None else []
    if not columns:
        return
    greeting = upload_assistant_message(
        columns,
        attendance_available=registry.attendance_available(),
        mode=InstitutionMode.from_label(st.session_state.get("institution_mode", InstitutionMode.GENERIC.value)),
    )
    messages = st.session_state.setdefault("chat_messages", [])
    messages.append({
        "role": "assistant",
        "content": greeting,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    })
    st.session_state["_greeted_workbook"] = file_name


def _handle_inline_edit_actions(loaded, current_user, permissions, privacy_settings) -> None:
    """The inline edit-plan card renders Run/Cancel buttons whose presses come
    back to us on the next rerun. We dispatch them here so the chat history can
    grow naturally with a success/failure assistant message."""
    from ui.chat_panel import append_assistant_message, mark_latest_edit_plan_resolved

    message_index = st.session_state.get("_chat_edit_plan_message_index")
    if message_index is None:
        return

    if st.session_state.get(f"edit_cancel_{message_index}"):
        mark_latest_edit_plan_resolved("cancelled")
        reset_current_interpretation()
        append_assistant_message("Cancelled. No workbook changes were made.")
        st.session_state.pop("_chat_edit_plan_message_index", None)
        return

    if not st.session_state.get(f"edit_run_{message_index}"):
        return

    # Run the planned action and post the result back into chat.
    mark_latest_edit_plan_resolved("executed")
    st.session_state.pop("_chat_edit_plan_message_index", None)
    success, message, output_file = _execute_current_plan(
        loaded=loaded,
        current_user=current_user,
        permissions=permissions,
        privacy_settings=privacy_settings,
    )
    attachment = {"type": "download", "path": output_file} if (success and output_file) else None
    append_assistant_message(message, attachment=attachment)


def _execute_current_plan(*, loaded, current_user, permissions, privacy_settings):
    """Wrap run_current_action so the chat panel can run an edit plan without
    rendering inline Streamlit alerts (those flash and disappear on rerun)."""
    command = st.session_state.get("current_command") or {}
    plan = st.session_state.get("current_plan") or {}
    request = st.session_state.get("current_request", "")
    source = st.session_state.get("current_source")
    confidence = st.session_state.get("current_confidence")

    plan_commands = plan.get("commands") or ([command] if command else [])

    if not permissions["can_execute"]:
        return False, "Your role can preview and ask questions but cannot run actions.", None
    if not command and not plan_commands:
        return False, "No interpreted command is ready to run.", None
    if st.session_state.get("current_validation_error"):
        return False, "Resolve validation issues before running this action.", None
    if any(is_delete_row_action(step) for step in plan_commands) and privacy_settings["block_delete_row_actions"]:
        return False, "This row-removal action is blocked by the current safety settings.", None

    try:
        if plan.get("commands"):
            plan_result = execute_plan(plan, loaded.workbook, loaded.sheets, loaded.file_name)
            result = ActionResult(
                message=plan_result.message,
                preview=plan_result.preview,
                result_sheet=plan_result.result_sheet,
            )
        else:
            result = execute_command(command, loaded.workbook, loaded.sheets, loaded.file_name)
        export_path = export_edited_workbook(loaded.workbook, loaded.file_name)
        log_audit_event(
            username=current_user.username,
            user_role=current_user.role,
            action_type=command.get("action"),
            columns_affected=affected_columns(command),
            row_count_affected=affected_row_count(command, loaded.sheets),
            success=True,
            source=source,
        )
        st.session_state["latest_output_file"] = str(export_path)
        st.session_state["latest_result_preview"] = result.preview
        st.session_state["latest_result_message"] = result.message
        st.session_state["latest_result_sheet"] = result.result_sheet
        st.session_state.setdefault("export_history", []).insert(0, Path(export_path).name)
        action_name = command.get("action") if isinstance(command, dict) else None
        if action_name in {"create_chart", "create_report", "count_by_group", "summarize_missing"} and result.preview is not None:
            st.session_state.setdefault("figures_history", []).insert(
                0,
                {"sheet": result.result_sheet, "action": action_name, "preview": result.preview, "message": result.message},
            )
        st.session_state["action_history"].insert(
            0,
            {
                "request": request,
                "action": command.get("action"),
                "confidence": confidence,
                "success": True,
                "output": str(export_path),
            },
        )
        st.session_state["pending_feedback"] = {
            "file_name": loaded.file_name,
            "sheet_name": command.get("sheet"),
            "original_request": request,
            "command": command,
            "parser_confidence": confidence,
            "parser_source": source,
            "action_type": command.get("action"),
        }
        reset_current_interpretation()
        return True, result.message, str(export_path)
    except Exception as exc:
        log_user_request(
            file_name=loaded.file_name,
            sheet_name=command.get("sheet") if isinstance(command, dict) else None,
            original_request=request,
            generated_command=command if isinstance(command, dict) else {},
            parser_confidence=confidence,
            parser_source=source,
            action_type=command.get("action") if isinstance(command, dict) else None,
            success=False,
            error_message=str(exc),
        )
        st.session_state["action_history"].insert(
            0,
            {
                "request": request,
                "action": command.get("action"),
                "confidence": confidence,
                "success": False,
                "output": "",
            },
        )
        return False, f"Action failed: {exc}", None


def render_sidebar_advanced(permissions, privacy_settings):
    """Advanced controls live in collapsed sidebar expanders. Returns
    (settings, privacy_settings, show_debug)."""
    if permissions["can_admin"]:
        settings = render_settings_panel()
        privacy_settings = render_privacy_admin()
        render_learning_admin()
        render_user_admin()
    else:
        settings = {"strict_privacy_mode": True, "use_local_llm": False, "ollama_model": "llama3.2:3b"}
        st.caption("Privacy mode is on. Ask an admin to change advanced settings.")
    show_debug = st.checkbox("Show developer/debug info", value=False, key="show_debug_toggle")
    return settings, privacy_settings, show_debug


def render_status_badges(loaded, settings: dict[str, Any]) -> None:
    """One compact strip — no st.columns wrappers that introduce stray blocks."""
    workbook_html = (
        '<span class="status-badge badge-green">Workbook loaded</span>'
        if loaded else
        '<span class="status-badge badge-gray">No workbook loaded</span>'
    )
    privacy_html = (
        '<span class="status-badge badge-green">Privacy protected</span>'
        if settings.get("strict_privacy_mode", True) else
        '<span class="status-badge badge-yellow">Privacy mode off</span>'
    )
    llm_html = (
        '<span class="status-badge badge-yellow">Local LLM on</span>'
        if settings.get("use_local_llm") else
        '<span class="status-badge badge-gray">Local LLM off</span>'
    )
    st.markdown(
        f'<div class="status-strip">{workbook_html}{privacy_html}{llm_html}</div>',
        unsafe_allow_html=True,
    )


def render_debug_panel(loaded, selected_sheet: str) -> None:
    from core.schema import build_debug_state, build_workbook_schema

    with st.expander("Developer / debug info", expanded=True):
        try:
            schema = build_workbook_schema(loaded.sheets)
            state = build_debug_state(
                st.session_state.get("assistant_memory") or {},
                schema,
                selected_sheet or (loaded.sheets and next(iter(loaded.sheets))) or "",
                routing=st.session_state.get("routing_debug"),
            )
            st.caption("Detected sheets, normalized schema, sensitivity, and live conversation state. No raw sensitive rows are shown.")
            st.json(state)
        except Exception as exc:  # noqa: BLE001
            st.error(f"Could not build debug state: {exc}")


if __name__ == "__main__":
    main()
