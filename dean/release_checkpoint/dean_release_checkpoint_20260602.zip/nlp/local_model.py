from __future__ import annotations

import json
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

from nlp.llm_json_parser import (
    LLMCommandError,
    ParsedPlan,
    parse_llm_plan,
    parse_llm_response,
)
from nlp.model_prompt import (
    OLLAMA_URL,
    build_conversational_prompt,
    build_expert_planner_prompt,
    build_explain_prompt,
    build_intent_prompt,
    build_prompt,
    build_query_planner_prompt,
)
from nlp.privacy_filter import check_local_model_request_privacy
from core.privacy_guard import PrivacyGuardError, assert_loopback_url


@dataclass(frozen=True)
class LocalModelResult:
    command: dict[str, Any] | None
    error: str | None = None


@dataclass(frozen=True)
class LocalPlannerResult:
    """Result of calling the local Ollama expert planner."""

    plan: ParsedPlan | None
    error: str | None = None
    source: str = "local_llm"


@dataclass(frozen=True)
class OllamaStatus:
    available: bool
    running: bool
    model_available: bool
    user_message: str
    detail: str | None = None


def get_ollama_status(model_name: str, timeout: int = 2) -> OllamaStatus:
    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return OllamaStatus(
            available=False,
            running=False,
            model_available=False,
            user_message="Local model setup is blocked by the localhost-only privacy check.",
            detail=str(exc),
        )

    try:
        request = urllib.request.Request(f"{OLLAMA_URL}/api/tags", method="GET")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        return OllamaStatus(
            available=False,
            running=False,
            model_available=False,
            user_message="Ollama is not running locally. The app will keep using the built-in rule-based parser.",
            detail=str(exc),
        )

    models = [item.get("name") for item in payload.get("models", [])]
    model_available = model_name in models
    if not model_available:
        return OllamaStatus(
            available=False,
            running=True,
            model_available=False,
            user_message=f"Ollama is running, but model `{model_name}` is not installed.",
            detail=f"Available models: {', '.join(models) if models else 'none'}",
        )
    return OllamaStatus(
        available=True,
        running=True,
        model_available=True,
        user_message=f"Ollama is ready with model `{model_name}`.",
    )


def test_ollama_connection(model_name: str) -> tuple[bool, str]:
    status = get_ollama_status(model_name, timeout=3)
    return status.available, status.user_message


def command_from_local_model(
    *,
    user_request: str,
    model_name: str,
    sheet_names: list[str],
    sheet_columns: dict[str, list[str]],
) -> LocalModelResult:
    """Legacy single-command path. Kept for backwards compatibility."""
    privacy_check = check_local_model_request_privacy(user_request)
    if not privacy_check.allowed:
        reasons = ", ".join(privacy_check.reasons)
        return LocalModelResult(
            command=None,
            error=f"Local model fallback was skipped because the request may contain sensitive data: {reasons}.",
        )

    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return LocalModelResult(command=None, error=str(exc))

    prompt = build_prompt(
        user_request=user_request,
        sheet_names=sheet_names,
        sheet_columns=sheet_columns,
    )
    raw_response, error = _call_ollama(prompt, model_name)
    if error or raw_response is None:
        return LocalModelResult(command=None, error=error)

    try:
        command = parse_llm_response(raw_response, sheet_columns)
    except LLMCommandError as exc:
        return LocalModelResult(command=None, error=str(exc))

    return LocalModelResult(command=command)


def plan_from_local_model(
    *,
    user_request: str,
    model_name: str,
    sheet_names: list[str],
    sheet_columns: dict[str, list[str]],
    mapped_columns: dict[str, str] | None = None,
) -> LocalPlannerResult:
    """Call the local Ollama planner and return a validated ParsedPlan envelope.

    The LLM only receives: the user request, sheet names, column names, mapped
    column concepts, the allowed actions, and the few-shot examples. Nothing
    about workbook data, file paths, or logs is included.
    """
    privacy_check = check_local_model_request_privacy(user_request)
    if not privacy_check.allowed:
        reasons = ", ".join(privacy_check.reasons)
        return LocalPlannerResult(
            plan=None,
            error=(
                "Local model fallback was skipped because the request may contain "
                f"sensitive data: {reasons}."
            ),
        )

    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return LocalPlannerResult(plan=None, error=str(exc))

    prompt = build_expert_planner_prompt(
        user_request=user_request,
        sheet_names=sheet_names,
        sheet_columns=sheet_columns,
        mapped_columns=mapped_columns,
    )
    raw_response, error = _call_ollama(prompt, model_name)
    if error or raw_response is None:
        return LocalPlannerResult(plan=None, error=error)

    try:
        plan = parse_llm_plan(raw_response, sheet_columns)
    except LLMCommandError as exc:
        return LocalPlannerResult(plan=None, error=str(exc))

    return LocalPlannerResult(plan=plan)


# Planner-sized JSON cold-start: llama3.2:3b ~25-40s, mistral:7b ~85-115s on
# Apple Silicon Q4. Sustained load (thermal throttling) slows both further, so
# a tight 60s timeout silently fails every LLM call back to the rule parser.
# Budget generously; the call still returns as soon as the model is done.
OLLAMA_TIMEOUT_SECONDS = 300

# Streamlit reruns on every interaction. If a slow LLM call is already running,
# a second rerun would spawn another one and pile up — that's what locks up the
# machine. This non-blocking lock makes the second caller fall back to the rule
# parser instead of queueing another model invocation.
_OLLAMA_INFLIGHT_LOCK = threading.Lock()


@dataclass(frozen=True)
class IntentResult:
    request_type: str | None
    confidence: float
    reason: str = ""
    error: str | None = None


def classify_intent_with_model(
    *,
    user_request: str,
    model_name: str,
    sheet_names: list[str],
    sheet_columns: dict[str, list[str]],
) -> IntentResult:
    """Ask the local model to classify ask/edit/clarify. Privacy-safe: only the
    message plus sheet and column names are sent."""
    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return IntentResult(None, 0.0, error=str(exc))

    prompt = build_intent_prompt(
        user_request=user_request,
        sheet_names=sheet_names,
        sheet_columns=sheet_columns,
    )
    raw, error = _call_ollama(prompt, model_name, num_ctx=SHORT_NUM_CTX)
    if error or raw is None:
        return IntentResult(None, 0.0, error=error)
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        return IntentResult(None, 0.0, error=f"Intent JSON parse failed: {exc}")
    request_type = payload.get("request_type")
    if request_type not in {"ask_question", "edit_workbook", "clarify"}:
        return IntentResult(None, 0.0, error=f"Invalid request_type: {request_type!r}")
    try:
        confidence = float(payload.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0
    return IntentResult(request_type, confidence, reason=str(payload.get("reason", "")))


def plan_query_from_local_model(
    *,
    user_request: str,
    model_name: str,
    sheet_names: list[str],
    sheet_columns: dict[str, list[str]],
    mapped_columns: dict[str, str] | None = None,
) -> tuple[dict[str, Any] | None, str | None]:
    """Produce an ask_question query plan. Returns (query_dict, error)."""
    privacy_check = check_local_model_request_privacy(user_request)
    if not privacy_check.allowed:
        reasons = ", ".join(privacy_check.reasons)
        return None, f"Query skipped (possible sensitive data): {reasons}."
    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return None, str(exc)

    prompt = build_query_planner_prompt(
        user_request=user_request,
        sheet_names=sheet_names,
        sheet_columns=sheet_columns,
        mapped_columns=mapped_columns,
    )
    raw, error = _call_ollama(prompt, model_name)
    if error or raw is None:
        return None, error
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, f"Query JSON parse failed: {exc}"
    payload["request_type"] = "ask_question"
    return payload, None


def explain_result_with_model(
    *,
    user_question: str,
    verified_result: dict[str, Any],
    model_name: str,
) -> tuple[str | None, str | None]:
    """Have the model phrase an already-computed result in plain English.

    The model receives only the question and the verified result summary (never
    raw rows), and is instructed not to recompute any numbers.
    """
    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return None, str(exc)
    prompt = build_explain_prompt(
        user_question=user_question,
        verified_result=verified_result,
    )
    raw, error = _call_ollama(prompt, model_name, json_mode=False, num_ctx=SHORT_NUM_CTX)
    if error or raw is None:
        return None, error
    return raw.strip(), None


def converse_about_result_with_model(
    *,
    user_question: str,
    understood_plan: str,
    verified_result: dict[str, Any],
    model_name: str,
    active_context: dict[str, Any] | None = None,
    hidden_sensitive_fields: list[str] | None = None,
    allowed_next_actions: list[str] | None = None,
) -> tuple[str | None, str | None]:
    """Conversational narrator that runs AFTER validated execution.

    Receives the user question, the interpretation, the verified result summary,
    active context, hidden-field names, and allowed next actions. Never sees
    rows. Returns a 1–3 sentence plain-text reply or (None, error).
    """
    try:
        assert_loopback_url(OLLAMA_URL)
    except PrivacyGuardError as exc:
        return None, str(exc)
    prompt = build_conversational_prompt(
        user_question=user_question,
        understood_plan=understood_plan,
        verified_result=verified_result,
        active_context=active_context,
        hidden_sensitive_fields=hidden_sensitive_fields,
        allowed_next_actions=allowed_next_actions,
    )
    raw, error = _call_ollama(prompt, model_name, json_mode=False, num_ctx=SHORT_NUM_CTX)
    if error or raw is None:
        return None, error
    return raw.strip(), None


PLANNER_NUM_CTX = 8192
"""Context window large enough to carry the expert-planner payload
(~5,200 tokens of playbooks + rules + few-shots, see knowledge/*.json)."""

SHORT_NUM_CTX = 2048
"""Context window for short prompts (intent classification, narrator,
explanation). Keeping these calls small frees ~500 MB of KV cache per call
on Apple Silicon when the model is loaded with default keep_alive=5m."""


def _call_ollama(
    prompt: str,
    model_name: str,
    timeout: int = OLLAMA_TIMEOUT_SECONDS,
    json_mode: bool = True,
    num_ctx: int = PLANNER_NUM_CTX,
) -> tuple[str | None, str | None]:
    payload = {
        "model": model_name,
        "prompt": prompt,
        "stream": False,
        "options": {
            "temperature": 0,
            "num_ctx": num_ctx,
        },
    }
    if json_mode:
        payload["format"] = "json"

    if not _OLLAMA_INFLIGHT_LOCK.acquire(blocking=False):
        return None, "Local Ollama is already busy with another request; using the rule parser."

    try:
        request = urllib.request.Request(
            f"{OLLAMA_URL}/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=timeout) as response:
            response_payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        return None, f"Local Ollama request failed: {exc}"
    finally:
        _OLLAMA_INFLIGHT_LOCK.release()

    text = response_payload.get("response", "") if isinstance(response_payload, dict) else ""
    if not text:
        return None, "Local Ollama returned an empty response."
    return text, None
