from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class SheetProfile:
    name: str
    row_count: int
    columns: list[str]


@dataclass(frozen=True)
class WorkbookProfile:
    file_name: str
    sheet_names: list[str]
    sheets: list[SheetProfile]


def profile_workbook(file_name: str, sheets: dict[str, pd.DataFrame]) -> WorkbookProfile:
    sheet_profiles = [
        SheetProfile(
            name=sheet_name,
            row_count=len(dataframe.index),
            columns=[str(column) for column in dataframe.columns],
        )
        for sheet_name, dataframe in sheets.items()
    ]

    return WorkbookProfile(
        file_name=file_name,
        sheet_names=list(sheets.keys()),
        sheets=sheet_profiles,
    )
