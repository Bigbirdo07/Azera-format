"""Read-only query engine for Ask Mode.

Every exact number the assistant reports is computed here with pandas, never by
the LLM. The engine takes a validated ask_question query plan and returns a
structured, factual result. The LLM may later phrase the result in plain
English, but it is not trusted to do arithmetic.

This module never mutates the workbook and never writes a file.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd


# Values that count as a "missing / incomplete" status for membership filters.
_BLANK_TOKENS = {"", "nan", "none", "null", "n/a", "na"}

ASK_OPERATIONS = {
    "count_rows",
    "count_unique",
    "list_unique",
    "percent_rows",
    "sum_column",
    "average_column",
    "min_column",
    "max_column",
    "groupby_count",
    "groupby_sum",
    "groupby_average",
    "missing_summary",
    "duplicate_check",
    "filtered_preview",
    "data_quality_summary",
}


class QueryExecutionError(ValueError):
    pass


@dataclass
class QueryResult:
    operation: str
    description: str  # factual, plain sentence the LLM may rephrase
    value: float | int | None = None
    row_count: int | None = None
    table: list[dict[str, Any]] = field(default_factory=list)
    columns_used: list[str] = field(default_factory=list)
    preview_truncated: bool = False


def run_query(query: dict[str, Any], sheets: dict[str, pd.DataFrame]) -> QueryResult:
    """Execute an ask_question query plan against in-memory DataFrames."""
    operation = query.get("operation")
    if operation not in ASK_OPERATIONS:
        raise QueryExecutionError(f"Unsupported ask operation: {operation!r}")

    sheet_name = query.get("sheet") or _default_sheet(sheets)
    if sheet_name not in sheets:
        raise QueryExecutionError(f"Unknown sheet: {sheet_name!r}")
    frame = sheets[sheet_name]

    filters = query.get("filters") or []
    filter_mode = (query.get("filter_mode") or "all").lower()
    if filter_mode not in {"all", "any"}:
        filter_mode = "all"
    group_by = query.get("group_by") or ""
    value_column = query.get("value_column") or ""
    sort_by = query.get("sort_by") or ""
    sort = query.get("sort") or None
    raw_limit = query.get("limit", 10)
    preview_limit = int(raw_limit or 10)
    group_limit = None if "limit" in query and raw_limit is None else int(raw_limit or 10)
    select_columns = [c for c in (query.get("select_columns") or []) if isinstance(c, str) and c]

    _assert_columns_exist(frame, filters, group_by, value_column)
    if sort and sort.get("column") and sort["column"] not in frame.columns:
        raise QueryExecutionError(f"Unknown column: {sort['column']!r}")
    for column in select_columns:
        if column not in frame.columns:
            raise QueryExecutionError(f"Unknown column: {column!r}")

    if operation == "count_rows":
        return _count_rows(frame, filters, filter_mode)
    if operation == "percent_rows":
        return _percent_rows(frame, filters, filter_mode)
    if operation == "count_unique":
        return _count_unique(frame, value_column or group_by, filters, filter_mode)
    if operation == "list_unique":
        return _list_unique(frame, value_column or group_by, filters, preview_limit, filter_mode)
    if operation == "sum_column":
        return _aggregate_column(frame, filters, value_column, "sum", filter_mode)
    if operation == "average_column":
        return _aggregate_column(frame, filters, value_column, "mean", filter_mode)
    if operation == "min_column":
        return _aggregate_column(frame, filters, value_column, "min", filter_mode)
    if operation == "max_column":
        return _aggregate_column(frame, filters, value_column, "max", filter_mode)
    if operation in {"groupby_count", "groupby_sum", "groupby_average"}:
        return _group_by(frame, filters, group_by, value_column, operation, sort_by, group_limit, sort, filter_mode)
    if operation == "missing_summary":
        return _missing_summary(frame)
    if operation == "duplicate_check":
        return _duplicate_check(frame, value_column or group_by)
    if operation == "filtered_preview":
        return _filtered_preview(frame, filters, preview_limit, sort, select_columns, filter_mode)
    if operation == "data_quality_summary":
        return _data_quality_summary(frame)

    raise QueryExecutionError(f"Unhandled operation: {operation!r}")


# Operations ------------------------------------------------------------------


def _count_rows(
    frame: pd.DataFrame, filters: list[dict[str, Any]], filter_mode: str = "all",
) -> QueryResult:
    mask = _build_mask(frame, filters, filter_mode)
    count = int(mask.sum())
    return QueryResult(
        operation="count_rows",
        value=count,
        row_count=count,
        description=f"{count} row(s) match the conditions.",
        columns_used=[f["column"] for f in filters if f.get("column")],
    )


def _percent_rows(
    frame: pd.DataFrame, filters: list[dict[str, Any]], filter_mode: str = "all",
) -> QueryResult:
    """Share of rows matching the filter, expressed as a percent of total."""
    total = int(len(frame))
    if total == 0:
        return QueryResult(
            operation="percent_rows", value=0.0, row_count=0,
            description="The sheet is empty, so the share is 0%.",
            columns_used=[f["column"] for f in filters if f.get("column")],
        )
    mask = _build_mask(frame, filters, filter_mode)
    matched = int(mask.sum())
    pct = round((matched / total) * 100, 2)
    return QueryResult(
        operation="percent_rows",
        value=pct,
        row_count=matched,
        description=f"{matched} of {total} row(s) match — {pct}% of the sheet.",
        columns_used=[f["column"] for f in filters if f.get("column")],
    )


def _count_unique(
    frame: pd.DataFrame, column: str,
    filters: list[dict[str, Any]] | None = None, filter_mode: str = "all",
) -> QueryResult:
    if not column or column not in frame.columns:
        raise QueryExecutionError("count_unique requires a known column.")
    filters = filters or []
    mask = _build_mask(frame, filters, filter_mode)
    count = int(frame.loc[mask, column].nunique(dropna=True))
    return QueryResult(
        operation="count_unique",
        value=count,
        row_count=count,
        description=f"There are {count} distinct {column} value(s).",
        columns_used=[column] + [f["column"] for f in filters if f.get("column")],
    )


def _list_unique(
    frame: pd.DataFrame, column: str, filters: list[dict[str, Any]] | None = None,
    limit: int = 10, filter_mode: str = "all",
) -> QueryResult:
    """Return the distinct values of a column (sorted) as the result table."""
    if not column or column not in frame.columns:
        raise QueryExecutionError("list_unique requires a known column.")
    filters = filters or []
    mask = _build_mask(frame, filters, filter_mode)
    series = frame.loc[mask, column].dropna()
    try:
        values = sorted(series.astype(str).unique().tolist())
    except TypeError:
        values = list(dict.fromkeys(series.astype(str).tolist()))
    total = len(values)
    truncated = isinstance(limit, int) and limit > 0 and total > limit
    visible = values[:limit] if isinstance(limit, int) and limit > 0 else values
    table = [{column: v} for v in visible]
    return QueryResult(
        operation="list_unique",
        value=total,
        row_count=total,
        table=table,
        description=f"{total} distinct {column} value(s).",
        columns_used=[column] + [f["column"] for f in filters if f.get("column")],
        preview_truncated=truncated,
    )


def _aggregate_column(
    frame: pd.DataFrame, filters: list[dict[str, Any]], value_column: str, how: str,
    filter_mode: str = "all",
) -> QueryResult:
    if not value_column:
        raise QueryExecutionError(f"{how} requires a value_column.")
    mask = _build_mask(frame, filters, filter_mode)
    numeric = pd.to_numeric(frame.loc[mask, value_column], errors="coerce")
    result = getattr(numeric, how)()
    value = None if pd.isna(result) else round(float(result), 4)
    label = {"sum": "Total", "mean": "Average", "min": "Minimum", "max": "Maximum"}[how]
    return QueryResult(
        operation=f"{'average' if how == 'mean' else how}_column",
        value=value,
        row_count=int(mask.sum()),
        description=f"{label} of {value_column} across matching rows is {value}.",
        columns_used=[value_column] + [f["column"] for f in filters if f.get("column")],
    )


def _group_by(
    frame: pd.DataFrame,
    filters: list[dict[str, Any]],
    group_by: str,
    value_column: str,
    operation: str,
    sort_by: str,
    limit: int | None,
    sort: dict[str, Any] | None = None,
    filter_mode: str = "all",
) -> QueryResult:
    if not group_by:
        raise QueryExecutionError("group operations require a group_by column.")
    mask = _build_mask(frame, filters, filter_mode)
    subset = frame.loc[mask]

    if operation == "groupby_count":
        grouped = subset.groupby(group_by, dropna=False).size().reset_index(name="Count")
        metric_column = "Count"
    else:
        if not value_column:
            raise QueryExecutionError(f"{operation} requires a value_column.")
        numeric = pd.to_numeric(subset[value_column], errors="coerce")
        agg = "sum" if operation == "groupby_sum" else "mean"
        grouped = (
            subset.assign(**{value_column: numeric})
            .groupby(group_by, dropna=False)[value_column]
            .agg(agg)
            .round(4)
            .reset_index()
        )
        metric_column = value_column

    # Sort direction: prefer the structured sort dict (which carries direction)
    # over the legacy sort_by string. Default to descending so existing callers
    # that only set sort_by keep their "top N" semantics.
    sort_column = sort_by if sort_by in grouped.columns else metric_column
    direction = "desc"
    if isinstance(sort, dict) and sort.get("column") in grouped.columns:
        sort_column = sort["column"]
        direction = str(sort.get("direction") or "desc").lower()
    ascending = direction == "asc"
    grouped = grouped.sort_values(sort_column, ascending=ascending)
    if limit is not None:
        grouped = grouped.head(limit)

    table = grouped.to_dict(orient="records")
    top = table[0] if table else {}
    superlative = "lowest" if ascending else "highest"
    top_desc = (
        f"{top.get(group_by)} has the {superlative} {metric_column} ({top.get(metric_column)})."
        if top
        else "No rows matched."
    )
    return QueryResult(
        operation=operation,
        row_count=int(mask.sum()),
        table=table,
        description=f"Grouped {metric_column} by {group_by}. {top_desc}",
        columns_used=[group_by] + ([value_column] if value_column else []),
    )


def _missing_summary(frame: pd.DataFrame) -> QueryResult:
    total = len(frame)
    rows = []
    for column in frame.columns:
        missing = int(_blank_mask(frame[column]).sum())
        if missing:
            rows.append(
                {
                    "Column": column,
                    "Missing": missing,
                    "Missing %": round(100 * missing / total, 1) if total else 0.0,
                }
            )
    rows.sort(key=lambda item: item["Missing"], reverse=True)
    if rows:
        worst = rows[0]
        desc = f"{len(rows)} column(s) have missing values; {worst['Column']} has the most ({worst['Missing']})."
    else:
        desc = "No columns have missing values."
    return QueryResult(
        operation="missing_summary",
        table=rows,
        row_count=total,
        description=desc,
        columns_used=[r["Column"] for r in rows],
    )


def _duplicate_check(frame: pd.DataFrame, column: str) -> QueryResult:
    if column and column in frame.columns:
        dup_mask = frame[column].duplicated(keep=False) & frame[column].notna()
        dup_count = int(dup_mask.sum())
        examples = (
            frame.loc[dup_mask, column].astype(str).value_counts().head(10).reset_index()
        )
        examples.columns = [column, "Occurrences"]
        return QueryResult(
            operation="duplicate_check",
            value=dup_count,
            row_count=dup_count,
            table=examples.to_dict(orient="records"),
            description=f"{dup_count} row(s) share a duplicated {column} value.",
            columns_used=[column],
        )
    dup_count = int(frame.duplicated(keep=False).sum())
    return QueryResult(
        operation="duplicate_check",
        value=dup_count,
        row_count=dup_count,
        description=f"{dup_count} fully duplicated row(s) found across all columns.",
        columns_used=list(frame.columns),
    )


def _filtered_preview(
    frame: pd.DataFrame,
    filters: list[dict[str, Any]],
    limit: int,
    sort: dict[str, Any] | None = None,
    select_columns: list[str] | None = None,
    filter_mode: str = "all",
) -> QueryResult:
    mask = _build_mask(frame, filters, filter_mode)
    matched = int(mask.sum())
    subset = frame.loc[mask]
    sort_note = ""
    if sort and sort.get("column") in frame.columns:
        ascending = str(sort.get("direction", "asc")).lower() != "desc"
        column = sort["column"]
        # Sort numerically when possible so GPA-like columns order correctly.
        numeric = pd.to_numeric(subset[column], errors="coerce")
        if numeric.notna().any():
            subset = subset.assign(_sort=numeric).sort_values("_sort", ascending=ascending).drop(columns="_sort")
        else:
            subset = subset.sort_values(column, ascending=ascending)
        sort_note = f", sorted by {column} {'ascending' if ascending else 'descending'}"
    preview = subset.head(limit)
    projection_note = ""
    columns_used = [f["column"] for f in filters if f.get("column")]
    if select_columns:
        kept = [c for c in select_columns if c in preview.columns]
        if kept:
            preview = preview[kept]
            projection_note = f", columns: {', '.join(kept)}"
            columns_used = list(dict.fromkeys(columns_used + kept))
    return QueryResult(
        operation="filtered_preview",
        row_count=matched,
        table=preview.to_dict(orient="records"),
        description=f"{matched} row(s) match; showing up to {limit}{sort_note}{projection_note}.",
        columns_used=columns_used,
        preview_truncated=matched > limit,
    )


def _data_quality_summary(frame: pd.DataFrame) -> QueryResult:
    total = len(frame)
    missing = _missing_summary(frame)
    full_dupes = int(frame.duplicated(keep=False).sum())
    rows = list(missing.table)
    rows.append({"Column": "(fully duplicated rows)", "Missing": full_dupes, "Missing %": ""})
    desc = (
        f"{total} rows scanned. {len(missing.table)} column(s) have missing values; "
        f"{full_dupes} fully duplicated row(s)."
    )
    return QueryResult(
        operation="data_quality_summary",
        row_count=total,
        table=rows,
        description=desc,
        columns_used=list(frame.columns),
    )


# Masking ---------------------------------------------------------------------


def _build_mask(
    frame: pd.DataFrame,
    filters: list[dict[str, Any]],
    mode: str = "all",
) -> pd.Series:
    """Combine each filter's mask under ``mode`` ("all" = AND, "any" = OR).

    Per-condition masks are computed in isolation so OR composes correctly —
    accumulating with ``mask |= ...`` against a True seed would always be True.
    """
    masks: list[pd.Series] = []
    for condition in filters:
        masks.append(_condition_mask(frame, condition))
    if not masks:
        return pd.Series(True, index=frame.index)
    if mode == "any":
        combined = masks[0]
        for m in masks[1:]:
            combined = combined | m
    else:
        combined = masks[0]
        for m in masks[1:]:
            combined = combined & m
    return combined.fillna(False)


def _condition_mask(frame: pd.DataFrame, condition: dict[str, Any]) -> pd.Series:
    """Compute the boolean mask for a single filter condition."""
    column = condition.get("column")
    operator = condition.get("operator")
    value = condition.get("value")
    series = frame[column]

    if operator == "in":
        return _membership_mask(series, value)
    if operator == "equals":
        return _text_eq(series, value)
    if operator == "not_equals":
        return ~_text_eq(series, value)
    if operator == "greater_than":
        return pd.to_numeric(series, errors="coerce") > float(value)
    if operator == "greater_or_equal":
        return pd.to_numeric(series, errors="coerce") >= float(value)
    if operator == "less_than":
        return pd.to_numeric(series, errors="coerce") < float(value)
    if operator == "less_or_equal":
        return pd.to_numeric(series, errors="coerce") <= float(value)
    if operator == "contains":
        return series.astype(str).str.contains(str(value), case=False, na=False)
    if operator == "contains_any":
        terms = value if isinstance(value, list) else [value]
        return series.astype(str).apply(
            lambda item: any(str(t).casefold() in item.casefold() for t in terms)
        )
    if operator == "not_contains":
        return ~series.astype(str).str.contains(str(value), case=False, na=False)
    if operator == "contains_text":
        # Semantically tagged for free-text columns. Same matching logic
        # as 'contains' (case-insensitive substring, NaN-safe) but the
        # downstream privacy layer treats matched rows differently —
        # the note column is hidden by default; only a 'Matched Notes'
        # indicator is shown unless the user confirms reveal.
        return series.astype(str).str.contains(str(value), case=False, na=False, regex=False)
    if operator == "not_contains_text":
        return ~series.astype(str).str.contains(str(value), case=False, na=False, regex=False)
    if operator == "starts_with":
        return series.astype(str).str.casefold().str.startswith(str(value).casefold()) & series.notna()
    if operator == "ends_with":
        return series.astype(str).str.casefold().str.endswith(str(value).casefold()) & series.notna()
    if operator == "between":
        low, high = _between_bounds(value)
        numeric = pd.to_numeric(series, errors="coerce")
        return (numeric >= low) & (numeric <= high)
    if operator == "not_in":
        return ~_membership_mask(series, value)
    if operator == "is_missing" or operator == "is_blank":
        return _blank_mask(series)
    if operator == "is_not_missing" or operator == "is_not_blank":
        return ~_blank_mask(series)
    raise QueryExecutionError(f"Unsupported operator: {operator!r}")


def _between_bounds(value: Any) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise QueryExecutionError("between requires a [low, high] value.")
    try:
        low, high = float(value[0]), float(value[1])
    except (TypeError, ValueError) as exc:
        raise QueryExecutionError("between bounds must be numeric.") from exc
    return (low, high) if low <= high else (high, low)


def _membership_mask(series: pd.Series, value: Any) -> pd.Series:
    values = value if isinstance(value, list) else [value]
    tokens = {str(v).strip().casefold() for v in values}
    wants_blank = bool(tokens & _BLANK_TOKENS)
    normalized = series.astype(str).str.strip().str.casefold()
    member = normalized.isin(tokens)
    if wants_blank:
        member = member | _blank_mask(series)
    return member


def _text_eq(series: pd.Series, value: Any) -> pd.Series:
    if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
        return series.astype(str).str.casefold() == str(value).casefold()
    return series == value


def _blank_mask(series: pd.Series) -> pd.Series:
    normalized = series.astype(str).str.strip().str.casefold()
    return series.isna() | normalized.isin(_BLANK_TOKENS)


# Helpers ---------------------------------------------------------------------


def _default_sheet(sheets: dict[str, pd.DataFrame]) -> str:
    return next(iter(sheets), "")


def _assert_columns_exist(
    frame: pd.DataFrame,
    filters: list[dict[str, Any]],
    group_by: str,
    value_column: str,
) -> None:
    referenced = [f.get("column") for f in filters if f.get("column")]
    if group_by:
        referenced.append(group_by)
    if value_column:
        referenced.append(value_column)
    for column in referenced:
        if column not in frame.columns:
            raise QueryExecutionError(f"Unknown column: {column!r}")
