"""Combined risk scoring — fold per-signal flags into one Risk Level column.

Signals (each independent, all optional depending on what data is loaded):
- GPA Risk          → GPA < 2.0
- Attendance Risk   → Attendance Rate < 90% (from core.attendance)
- Standing Risk     → Academic Standing in {Warning, Probation, At Risk}
- Assessment Risk   → PSAT/SAT Benchmark Status indicates below benchmark

Aggregation:
- Risk Signals = count of True signals
- Risk Level = High (>=2) | Moderate (==1) | Low (==0)

All inputs are looked up case-insensitively; missing columns simply skip
that signal — a roster with no Academic Standing column still gets the
GPA + attendance signals.
"""

from __future__ import annotations

import pandas as pd


GPA_RISK_THRESHOLD = 2.0
ATTENDANCE_RISK_THRESHOLD = 90.0
AT_RISK_STANDING_VALUES = {"warning", "probation", "at risk", "academic warning",
                           "academic probation"}
BELOW_BENCHMARK_VALUES = {"below benchmark", "did not meet", "did not meet benchmark",
                          "below", "not met"}
HIGH_RISK_SIGNAL_COUNT = 2
MODERATE_RISK_SIGNAL_COUNT = 1


def attach_combined_risk(
    roster: pd.DataFrame,
    *,
    gpa_threshold: float | None = None,
    attendance_threshold: float | None = None,
    high_count: int | None = None,
    moderate_count: int | None = None,
) -> pd.DataFrame:
    """Add Risk Signals + Risk Level + per-signal boolean columns + a
    human-readable Risk Reason to the roster. Returns a copy — never
    mutates the input frame.

    All threshold kwargs are optional. When omitted, the module constants
    apply (preserves historical behaviour for tests + existing callers);
    when supplied, they let the caller plumb ``RiskSettings`` straight in.
    """
    gpa_t = gpa_threshold if gpa_threshold is not None else GPA_RISK_THRESHOLD
    att_t = attendance_threshold if attendance_threshold is not None else ATTENDANCE_RISK_THRESHOLD
    high_t = high_count if high_count is not None else HIGH_RISK_SIGNAL_COUNT
    mod_t = moderate_count if moderate_count is not None else MODERATE_RISK_SIGNAL_COUNT

    if roster is None or roster.empty:
        return roster

    out = roster.copy()
    signals: list[pd.Series] = []
    # Per-row reason fragments — joined into a single Risk Reason column
    # at the bottom so we can explain WHY a student lights up.
    reason_fragments: list[pd.Series] = []

    gpa_col = _find_column(out.columns, ("gpa", "cumulative gpa", "cum gpa"))
    if gpa_col:
        gpa_numeric = pd.to_numeric(out[gpa_col], errors="coerce")
        out["GPA Risk"] = gpa_numeric < gpa_t
        signals.append(out["GPA Risk"].fillna(False))
        reason_fragments.append(_label_when_true(
            out["GPA Risk"].fillna(False), f"GPA below {_fmt_threshold(gpa_t)}",
        ))

    if "Attendance Rate" in out.columns:
        out["Attendance Risk"] = (
            pd.to_numeric(out["Attendance Rate"], errors="coerce") < att_t
        )
        signals.append(out["Attendance Risk"].fillna(False))
        reason_fragments.append(_label_when_true(
            out["Attendance Risk"].fillna(False),
            f"Attendance below {_fmt_threshold(att_t)}%",
        ))

    standing_col = _find_column(out.columns, ("academic standing", "standing", "status"))
    if standing_col:
        normalized = out[standing_col].astype(str).str.strip().str.lower()
        out["Standing Risk"] = normalized.isin(AT_RISK_STANDING_VALUES)
        signals.append(out["Standing Risk"].fillna(False))
        reason_fragments.append(_standing_reason(out[standing_col], out["Standing Risk"].fillna(False)))

    bench_col = _find_column(out.columns, ("benchmark status", "psat benchmark",
                                            "sat benchmark", "assessment benchmark"))
    if bench_col:
        normalized = out[bench_col].astype(str).str.strip().str.lower()
        out["Assessment Risk"] = normalized.isin(BELOW_BENCHMARK_VALUES)
        signals.append(out["Assessment Risk"].fillna(False))
        reason_fragments.append(_label_when_true(
            out["Assessment Risk"].fillna(False),
            "Assessment below benchmark",
        ))

    if not signals:
        out["Risk Signals"] = 0
        out["Risk Level"] = "Low Risk"
        out["Risk Reason"] = ""
        return out

    counts = signals[0].astype(int)
    for s in signals[1:]:
        counts = counts + s.astype(int)
    out["Risk Signals"] = counts
    out["Risk Level"] = counts.apply(
        lambda n: _risk_level_for_count(n, high_t, mod_t),
    )
    out["Risk Reason"] = _join_reason_fragments(reason_fragments)
    return out


def _risk_level_for_count(n: int, high_t: int = 2, mod_t: int = 1) -> str:
    if n >= high_t:
        return "High Risk"
    if n >= mod_t:
        return "Moderate Risk"
    return "Low Risk"


def _label_when_true(mask: pd.Series, label: str) -> pd.Series:
    return mask.map(lambda flag: label if bool(flag) else "")


def _standing_reason(values: pd.Series, mask: pd.Series) -> pd.Series:
    return values.astype(str).where(mask, "").map(
        lambda value: f"Academic Standing = {value.strip()}" if value.strip() else "",
    )


def _join_reason_fragments(fragments: list[pd.Series]) -> pd.Series:
    if not fragments:
        return pd.Series([""] * 0)
    out = fragments[0]
    for frag in fragments[1:]:
        out = out + frag.map(lambda v: ("; " + v) if v else "")
        # Joining a non-empty fragment to an empty one shouldn't prepend "; ".
    # Strip stray leading separators (when only later fragments were True).
    return out.str.replace(r"^;\s*", "", regex=True).str.strip()


def _fmt_threshold(value: float) -> str:
    if isinstance(value, int) or float(value).is_integer():
        return f"{value:.1f}" if value < 10 else f"{int(value)}"
    return f"{value:g}"


def _find_column(columns, variants: tuple[str, ...]) -> str | None:
    norm_map = {str(c).strip().lower(): c for c in columns}
    for variant in variants:
        if variant in norm_map:
            return norm_map[variant]
    for variant in variants:
        for norm, original in norm_map.items():
            if variant in norm:
                return original
    return None
