"""PSAT/SAT assessment schema — stubbed for the attendance-first rollout.

Why this is a stub
==================
Attendance was prioritised in the phase plan; the assessment loader is the
*next* slice. Shipping the schema now lets the Data Sources panel render an
"Assessments" tab with the right empty state, and gives ``combined_risk``
something concrete to look up (Benchmark Status) when an assessment frame
eventually lands.

Planned fields
--------------
- Student ID
- Test Type            (PSAT | SAT)
- Test Date
- Math Score
- Reading/Writing Score
- Total Score
- Benchmark Status     (Met Benchmark | Below Benchmark | Did Not Meet)

Planned operations (NOT implemented yet — DO NOT call from production code)
- below_sat_math_benchmark        → filter Math Score < threshold
- below_sat_reading_benchmark     → filter Reading/Writing Score < threshold
- total_below_threshold           → filter Total Score < threshold
- average_score_by_department     → groupby_average(Department, Total Score)
- score_trend                     → per-student deltas when multiple Test Dates exist

When implementing, mirror the attendance loader:
1. ``load_assessment_file`` canonicalises column names + parses Test Date.
2. ``compute_assessment_metrics`` produces a per-Student-ID frame keyed
   by latest test (most recent Test Date wins on duplicates).
3. ``DataSourceRegistry.enriched_sheets`` merges Math / Reading / Total /
   Benchmark Status onto the roster the same way attendance metrics do.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pandas as pd


ASSESSMENT_FIELDS = (
    "Student ID",
    "Test Type",
    "Test Date",
    "Math Score",
    "Reading/Writing Score",
    "Total Score",
    "Benchmark Status",
)

# Conservative thresholds — these are placeholders until the spec for what
# "below benchmark" means in *this* district lands. Treat as guidance only.
PLACEHOLDER_SAT_MATH_BENCHMARK = 530
PLACEHOLDER_SAT_READING_BENCHMARK = 480


@dataclass(frozen=True)
class AssessmentSchema:
    fields: tuple[str, ...] = ASSESSMENT_FIELDS


def load_assessment_file(uploaded_file: Any) -> None:
    """Deferred. The Data Sources panel surfaces a 'not yet supported'
    notice in the Assessments tab; once attendance is shipped, this becomes
    the assessment-side counterpart to ``core.attendance.load_attendance_file``."""
    raise NotImplementedError(
        "Assessment loading is part of Phase F, deferred behind attendance. "
        "Implement after the attendance flow is stable end-to-end."
    )
