"""L.1 + L.2: always-on conversational mode and plain-English plan narration."""

from __future__ import annotations

import json

import pytest

from core import execution_dispatcher
from core.execution_dispatcher import execute_planned_request
from core.llm_config import from_app_settings
from nlp.narration import narrate_plan
from nlp.planner_router import plan_user_request


# ---- narration unit tests ---------------------------------------------------


def test_narration_handles_simple_filter():
    plan = {
        "operation": "filtered_preview",
        "filters": [
            {"column": "Department", "operator": "equals", "value": "Accounting"},
            {"column": "GPA", "operator": "less_than", "value": 2.5},
        ],
    }
    text = narrate_plan(plan=plan)
    assert text.startswith("I understood this as")
    assert "Department" in text and "Accounting" in text
    assert "GPA" in text and "2.5" in text


def test_narration_handles_followup_replacement():
    prior = [{"column": "Department", "operator": "equals", "value": "Accounting"}]
    new = [{"column": "Department", "operator": "equals", "value": "Biology"}]
    plan = {"operation": "filtered_preview", "filters": new}
    text = narrate_plan(plan=plan, context_action="followup",
                        prior_filters=prior, new_filters=new, additive=False)
    assert "replaced" in text.lower()
    assert "Biology" in text


def test_narration_handles_groupby_followup():
    prior = [{"column": "Department", "operator": "equals", "value": "Accounting"}]
    plan = {"operation": "groupby_count", "filters": prior, "group_by": "Advisor"}
    text = narrate_plan(plan=plan, context_action="followup",
                        prior_filters=prior, new_filters=[], additive=False)
    assert "Advisor" in text


def test_narration_includes_sort_and_limit():
    plan = {
        "operation": "filtered_preview",
        "filters": [{"column": "GPA", "operator": "less_than", "value": 3.0}],
        "sort": {"column": "GPA", "direction": "ascending"},
        "limit": 5,
    }
    text = narrate_plan(plan=plan)
    assert "sorted" in text.lower()
    assert "5" in text


# ---- planner_router emits narration ----------------------------------------


def _route(message, sheets, columns, *, state=None):
    return plan_user_request(
        user_message=message,
        sheets=sheets,
        sheet_columns={"Students": columns},
        selected_sheet="Students",
        conversation_state=state,
        settings={"llm_enabled": False},
    )


def test_routing_includes_narration_on_rules_path(sheets, columns):
    routing = _route("Show me Accounting students", sheets, columns)
    assert routing["plan_source"] == "rules"
    assert routing["narration"].startswith("I understood this as")
    assert "Accounting" in routing["narration"]


def test_routing_narration_describes_followup(sheets, columns):
    state = {
        "active_filters": [{"column": "Department", "operator": "equals", "value": "Accounting"}],
        "sheet": "Students",
    }
    routing = _route("what about Biology", sheets, columns, state=state)
    assert "Biology" in routing["narration"]
    assert "replaced" in routing["narration"].lower()


# ---- llm_config strict-privacy gating --------------------------------------


def test_strict_privacy_forces_conversation_llm_off():
    config = from_app_settings({
        "use_local_llm": True,
        "conversation_llm_enabled": True,
        "strict_privacy_mode": True,
    })
    assert config["llm_enabled"] is False
    assert config["conversation_llm_enabled"] is False


def test_conversation_llm_requires_llm_enabled():
    # Even if conversation toggle is on, the umbrella LLM must be enabled.
    config = from_app_settings({
        "use_local_llm": False,
        "conversation_llm_enabled": True,
        "strict_privacy_mode": False,
    })
    assert config["conversation_llm_enabled"] is False


def test_conversation_llm_on_when_both_set():
    config = from_app_settings({
        "use_local_llm": True,
        "conversation_llm_enabled": True,
        "strict_privacy_mode": False,
    })
    assert config["llm_enabled"] is True
    assert config["conversation_llm_enabled"] is True


# ---- dispatcher: conversational narrator never sees rows -------------------


class _Loaded:
    def __init__(self, sheets):
        self.sheets = sheets
        self.file_name = "synthetic_students.xlsx"


def test_dispatcher_conversation_payload_excludes_rows(sheets, columns, monkeypatch):
    captured: dict = {}

    def fake_converse(**kwargs):
        captured.update(kwargs)
        return "Conversational reply.", None

    # Patch the import inside _run_query.
    import nlp.local_model as lm
    monkeypatch.setattr(lm, "converse_about_result_with_model", fake_converse)

    routing = _route("Show me Accounting students", sheets, columns)
    settings = {
        "use_local_llm": True,
        "conversation_llm_enabled": True,
        "strict_privacy_mode": False,
    }
    response = execute_planned_request(routing, _Loaded(sheets), settings,
                                       request_summary="Show me Accounting students")

    # The conversational narrator was called.
    assert response["conversation_llm_used"] is True
    assert response["message"] == "Conversational reply."

    # The payload sent to the model must NEVER include raw rows.
    payload_json = json.dumps(captured, default=str)
    assert "result_preview" not in captured
    # The verified result must only carry summary fields, not row dicts.
    verified = captured["verified_result"]
    assert set(verified.keys()) <= {"operation", "value", "row_count", "description", "columns"}
    # And the active_context only carries plan-level metadata (no rows).
    active = captured["active_context"]
    assert "filters" in active
    # Sanity: no student-level identifiers in the payload.
    for forbidden in ("@", "555-", "Student ID", "ssn"):
        assert forbidden.lower() not in payload_json.lower()


def test_dispatcher_falls_back_to_deterministic_message_when_llm_disabled(sheets, columns):
    routing = _route("Show me Accounting students", sheets, columns)
    response = execute_planned_request(routing, _Loaded(sheets), settings={
        "use_local_llm": False,
        "conversation_llm_enabled": False,
        "strict_privacy_mode": False,
    }, request_summary="Show me Accounting students")
    assert response["conversation_llm_used"] is False
    assert response["narration"].startswith("I understood this as")
    # The deterministic message leads with narration.
    assert response["message"].startswith("I understood this as")


def test_dispatcher_strict_privacy_skips_conversation_llm(sheets, columns, monkeypatch):
    called = {"n": 0}

    def fake_converse(**kwargs):
        called["n"] += 1
        return "Should not be called.", None

    import nlp.local_model as lm
    monkeypatch.setattr(lm, "converse_about_result_with_model", fake_converse)

    routing = _route("Show me Accounting students", sheets, columns)
    response = execute_planned_request(routing, _Loaded(sheets), settings={
        "use_local_llm": True,
        "conversation_llm_enabled": True,
        "strict_privacy_mode": True,
    }, request_summary="Show me Accounting students")

    assert called["n"] == 0
    assert response["conversation_llm_used"] is False


# ---- L.8: strict privacy preserves sanitized logging ------------------------


def test_strict_privacy_still_allows_interaction_logging(tmp_path):
    """Per L.8 (Option A): strict privacy disables LLM calls but interaction
    logging remains because the log is sanitized at write time."""
    from core.interaction_logger import log_interaction, read_records

    log_path = tmp_path / "log.jsonl"
    routing = {
        "plan_source": "rules", "intent": "query", "confidence": 0.9, "band": "high",
        "validation": {"status": "passed", "errors": []},
        "plan": {"operation": "filtered_preview", "sheet": "Students", "filters": []},
    }
    entry_id = log_interaction(
        user_message="Show me Accounting students",
        routing=routing,
        response={"response_type": "answer", "row_count": 5, "columns": []},
        session_id="s1",
        sheet_columns={"Students": ["Department"]},
        enabled=True,  # logging stays on under strict privacy
        path=log_path,
    )
    assert entry_id
    assert len(read_records(log_path)) == 1


def test_logging_can_be_disabled_independently(tmp_path):
    from core.interaction_logger import log_interaction, read_records

    log_path = tmp_path / "log.jsonl"
    entry_id = log_interaction(
        user_message="anything",
        routing={"plan_source": "rules", "intent": "query", "confidence": 0.9,
                 "validation": {"status": "passed", "errors": []},
                 "plan": {"operation": "filtered_preview"}},
        response=None,
        session_id="s1",
        enabled=False,
        path=log_path,
    )
    assert entry_id is None
    assert read_records(log_path) == []


# ---- L.10 closing: low-confidence path still clarifies ----------------------


def test_low_confidence_message_clarifies(sheets, columns):
    """A message that matches no rule and no LLM produces a clarification."""
    routing = _route("flarble glarble whatever", sheets, columns)
    assert routing["intent"] == "clarify"
    assert routing["band"] in {"low", "high"}  # band may not apply to non-query intents
